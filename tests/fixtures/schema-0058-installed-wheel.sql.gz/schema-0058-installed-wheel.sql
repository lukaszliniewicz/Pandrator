BEGIN TRANSACTION;
CREATE TABLE agent_runs (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(80) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	job_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	source_content_hash VARCHAR(128), 
	settings_hash VARCHAR(128), 
	checkpoint_revision INTEGER NOT NULL, 
	error_message TEXT, 
	settings_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE agent_steps (
	id VARCHAR(36) NOT NULL, 
	agent_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	unit_key VARCHAR(160), 
	input_hash VARCHAR(128), 
	phase VARCHAR(80) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	summary TEXT, 
	input_json JSON NOT NULL, 
	output_json JSON NOT NULL, 
	cost_usd FLOAT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_step_ordinal UNIQUE (agent_run_id, ordinal), 
	CONSTRAINT uq_agent_step_unit_key UNIQUE (agent_run_id, unit_key), 
	FOREIGN KEY(agent_run_id) REFERENCES agent_runs (id) ON DELETE CASCADE
);
CREATE TABLE alembic_version (
	version_num VARCHAR(32) NOT NULL, 
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
INSERT INTO "alembic_version" VALUES('0058_project_folders');
CREATE TABLE api_idempotency (
	id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(200) NOT NULL, 
	operation_id VARCHAR(160) NOT NULL, 
	idempotency_key VARCHAR(200) NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	status_code INTEGER, 
	response_json JSON, 
	resource_kind VARCHAR(80), 
	resource_id VARCHAR(160), 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_api_idempotency_principal_operation_key UNIQUE (principal_subject, operation_id, idempotency_key)
);
CREATE TABLE api_tokens (
	id VARCHAR(36) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	token_hash VARCHAR(128) NOT NULL, 
	token_prefix VARCHAR(16) NOT NULL, 
	subject VARCHAR(200), 
	scopes_json JSON NOT NULL, 
	expires_at DATETIME, 
	principal_kind VARCHAR(40) NOT NULL, 
	created_by VARCHAR(200), 
	client_id VARCHAR(36), 
	target_instance_id VARCHAR(36), 
	canonical_origin TEXT, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE SET NULL
);
CREATE TABLE app_settings (
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY ("key")
);
INSERT INTO "app_settings" VALUES('qualification.upgrade','{"synthetic": true, "threshold": 1800}',1,'2026-10-30 06:34:39.553634');
CREATE TABLE app_settings_history (
	id INTEGER NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE artifact_edges (
	parent_artifact_id VARCHAR(36) NOT NULL, 
	child_artifact_id VARCHAR(36) NOT NULL, 
	relation VARCHAR(80) NOT NULL, 
	PRIMARY KEY (parent_artifact_id, child_artifact_id), 
	FOREIGN KEY(parent_artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE, 
	FOREIGN KEY(child_artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE
);
CREATE TABLE artifacts (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36), 
	kind VARCHAR(80) NOT NULL, 
	role VARCHAR(120) NOT NULL, 
	relative_path TEXT NOT NULL, 
	mime_type VARCHAR(160), 
	size_bytes INTEGER, 
	content_hash VARCHAR(128), 
	state VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_artifact_relative_path UNIQUE (relative_path), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
INSERT INTO "artifacts" VALUES('0651510a-3772-471f-a33a-fdcf8c7d2fcc','8203a868-0859-486c-8a96-3924746866be','audio','source_media','artifacts/upgrade-qualification/source.wav','audio/x-wav',32044,'643f8a8dc8bd9c19225afffad2becfec5426180b3749cb208abdf1a6c8354efc','current',NULL,'{}','2026-10-30 06:34:39.512519','2026-10-30 06:34:39.512523');
INSERT INTO "artifacts" VALUES('f23b756e-d7ff-4760-baa0-76eea3502725','8203a868-0859-486c-8a96-3924746866be','subtitles','transcription','artifacts/upgrade-qualification/transcription.srt','text/plain',61,'8903877cc47a6e3c1e5b9f2888c75879d40c82938cad5c20f36d7edfb8973eb5','current',NULL,'{"language": "en", "revision_id": "2a7da01e-066c-4104-88e3-b464ff8b8b55"}','2026-10-30 06:34:39.530921','2026-10-30 06:34:39.530927');
CREATE TABLE audio_takes (
	id VARCHAR(36) NOT NULL, 
	generation_segment_id VARCHAR(36) NOT NULL, 
	generation_run_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	parent_take_id VARCHAR(36), 
	kind VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	duration_ms INTEGER, 
	is_active BOOLEAN NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(generation_segment_id) REFERENCES generation_segments (id) ON DELETE CASCADE, 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(parent_take_id) REFERENCES audio_takes (id) ON DELETE SET NULL
);
CREATE TABLE audit_events (
	id INTEGER NOT NULL, 
	request_id VARCHAR(80) NOT NULL, 
	traceparent VARCHAR(80), 
	principal_subject VARCHAR(200) NOT NULL, 
	principal_kind VARCHAR(40) NOT NULL, 
	scopes_json JSON NOT NULL, 
	action VARCHAR(160) NOT NULL, 
	method VARCHAR(12) NOT NULL, 
	path VARCHAR(500) NOT NULL, 
	idempotency_key VARCHAR(200), 
	plan_id VARCHAR(120), 
	plan_digest VARCHAR(128), 
	resource_kind VARCHAR(80), 
	resource_id VARCHAR(160), 
	outcome VARCHAR(40) NOT NULL, 
	status_code INTEGER NOT NULL, 
	duration_ms INTEGER NOT NULL, 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE automation_clients (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(160) NOT NULL, 
	subject VARCHAR(200) NOT NULL, 
	redirect_uris_json JSON NOT NULL, 
	allowed_scopes_json JSON NOT NULL, 
	target_instance_id VARCHAR(36) NOT NULL, 
	canonical_origin TEXT NOT NULL, 
	created_by VARCHAR(200) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (subject)
);
CREATE TABLE automation_enrollment_grants (
	id VARCHAR(36) NOT NULL, 
	client_id VARCHAR(36) NOT NULL, 
	code_hash VARCHAR(128) NOT NULL, 
	code_prefix VARCHAR(16) NOT NULL, 
	redirect_uri TEXT, 
	scopes_json JSON NOT NULL, 
	code_challenge VARCHAR(128) NOT NULL, 
	code_challenge_method VARCHAR(16) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	token_expires_at DATETIME NOT NULL, 
	consumed_at DATETIME, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE CASCADE, 
	UNIQUE (code_hash)
);
CREATE TABLE capability_snapshots (
	id INTEGER NOT NULL, 
	payload_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	output_role VARCHAR(120) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40), 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	result_revision_id VARCHAR(36), 
	glossary_json JSON NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL
);
CREATE TABLE document_revisions (
	id VARCHAR(36) NOT NULL, 
	document_id VARCHAR(36) NOT NULL, 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	reviewed BOOLEAN NOT NULL, 
	settings_hash VARCHAR(128), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_document_revision UNIQUE (document_id, revision_number), 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL
);
INSERT INTO "document_revisions" VALUES('2a7da01e-066c-4104-88e3-b464ff8b8b55','b2f03cdb-ea80-428a-8237-618f9558e3c8',NULL,1,'8903877cc47a6e3c1e5b9f2888c75879d40c82938cad5c20f36d7edfb8973eb5',1,NULL,'2026-10-30 06:34:39.520957');
CREATE TABLE documents (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	stage VARCHAR(80) NOT NULL, 
	language VARCHAR(40), 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
INSERT INTO "documents" VALUES('b2f03cdb-ea80-428a-8237-618f9558e3c8','8203a868-0859-486c-8a96-3924746866be','transcription','en','2a7da01e-066c-4104-88e3-b464ff8b8b55','2026-10-30 06:34:39.519211');
CREATE TABLE exports (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	options_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE generation_plan_revisions (
	id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36), 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	settings_json JSON NOT NULL, 
	operation_json JSON NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_generation_plan_revision UNIQUE (plan_id, revision_number), 
	FOREIGN KEY(plan_id) REFERENCES generation_plans (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(parent_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE SET NULL
);
CREATE TABLE generation_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE generation_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	source_generation_run_id VARCHAR(36), 
	output_generation_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	sequence_number INTEGER NOT NULL, 
	operation VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	pause_requested BOOLEAN NOT NULL, 
	cancel_requested BOOLEAN NOT NULL, 
	resume_source_on_completion BOOLEAN NOT NULL, 
	settings_snapshot_json JSON NOT NULL, 
	audio_version_json JSON, 
	settings_hash VARCHAR(128), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_generation_run_sequence UNIQUE (session_id, sequence_number), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(output_generation_run_id) REFERENCES generation_runs (id) ON DELETE CASCADE, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE generation_segment_revisions (
	id INTEGER NOT NULL, 
	generation_segment_id VARCHAR(36) NOT NULL, 
	revision INTEGER NOT NULL, 
	ordinal INTEGER, 
	source_segment_ids_json JSON NOT NULL, 
	speech_block_provenance_json JSON NOT NULL, 
	alignment_group VARCHAR(64), 
	node_kind VARCHAR(40) NOT NULL, 
	paragraph_break_after BOOLEAN NOT NULL, 
	speaker VARCHAR(160), 
	text TEXT NOT NULL, 
	optimized_text TEXT, 
	speech_plan_json JSON NOT NULL, 
	optimization_status VARCHAR(32) NOT NULL, 
	optimization_reviewed BOOLEAN NOT NULL, 
	marked BOOLEAN NOT NULL, 
	removed BOOLEAN NOT NULL, 
	voice_id VARCHAR(36), 
	voice VARCHAR(255), 
	language VARCHAR(40), 
	silence_after_ms INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(generation_segment_id) REFERENCES generation_segments (id) ON DELETE CASCADE
);
CREATE TABLE generation_segments (
	id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	source_segment_ids_json JSON NOT NULL, 
	speech_block_provenance_json JSON NOT NULL, 
	alignment_group VARCHAR(64), 
	node_kind VARCHAR(40) NOT NULL, 
	paragraph_break_after BOOLEAN NOT NULL, 
	speaker VARCHAR(160), 
	text TEXT NOT NULL, 
	optimized_text TEXT, 
	speech_plan_json JSON NOT NULL, 
	optimization_status VARCHAR(32) NOT NULL, 
	optimization_source_hash VARCHAR(128), 
	optimization_reviewed BOOLEAN NOT NULL, 
	optimization_model VARCHAR(255), 
	voice_id VARCHAR(36), 
	voice VARCHAR(255), 
	language VARCHAR(40), 
	silence_after_ms INTEGER NOT NULL, 
	marked BOOLEAN NOT NULL, 
	removed BOOLEAN NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_generation_segment_ordinal UNIQUE (plan_revision_id, ordinal), 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE, 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE SET NULL
);
CREATE TABLE job_events (
	id INTEGER NOT NULL, 
	job_id VARCHAR(36), 
	event_type VARCHAR(80) NOT NULL, 
	payload_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE CASCADE
);
CREATE TABLE jobs (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(120) NOT NULL, 
	session_id VARCHAR(36), 
	workflow_run_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	payload_json JSON NOT NULL, 
	resource_keys_json JSON NOT NULL, 
	result_json JSON, 
	progress FLOAT NOT NULL, 
	progress_detail TEXT, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	lease_owner VARCHAR(120), 
	lease_expires_at DATETIME, 
	lease_generation INTEGER NOT NULL, 
	available_at DATETIME, 
	attempts INTEGER NOT NULL, 
	max_attempts INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME, 
	finished_at DATETIME, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE CASCADE
);
INSERT INTO "jobs" VALUES('2fa7f85f-14ec-4a88-9eaa-e66bd4c0a2be','diagnostic.noop','8203a868-0859-486c-8a96-3924746866be',NULL,'queued','{"synthetic": "upgrade-qualification"}','[]',NULL,0.0,NULL,NULL,NULL,NULL,NULL,0,NULL,0,1,'2026-10-30 06:34:39.555795',NULL,NULL,'2026-10-30 06:34:39.555800');
CREATE TABLE knowledge_ledgers (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40) NOT NULL, 
	payload_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_knowledge_ledger_scope UNIQUE (session_id, kind, source_language, target_language), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE media_edit_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_media_edit_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES media_edit_dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE media_edit_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_revision_number INTEGER NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	instructions TEXT NOT NULL, 
	settings_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	result_revision_id VARCHAR(36), 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(result_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE SET NULL
);
CREATE TABLE media_edit_plan_revisions (
	id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	source_media_artifact_id VARCHAR(36) NOT NULL, 
	editorial_transcript_artifact_id VARCHAR(36) NOT NULL, 
	timing_artifact_id VARCHAR(36), 
	duration_ms INTEGER NOT NULL, 
	instructions TEXT NOT NULL, 
	keep_ranges_json JSON NOT NULL, 
	cues_json JSON NOT NULL, 
	evidence_json JSON NOT NULL, 
	operation_json JSON NOT NULL, 
	reviewed BOOLEAN NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_media_edit_plan_revision UNIQUE (plan_id, revision_number), 
	FOREIGN KEY(plan_id) REFERENCES media_edit_plans (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_media_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(editorial_transcript_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(timing_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE media_edit_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE outcome_plan_history (
	id INTEGER NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE outcome_plans (
	session_id VARCHAR(36) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE output_assemblies (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	generation_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	settings_hash VARCHAR(128), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE owner_account (
	singleton_id INTEGER NOT NULL, 
	password_hash TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (singleton_id)
);
CREATE TABLE performance_batches (
	id VARCHAR(36) NOT NULL, 
	performance_plan_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	segment_ids_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	lease_token VARCHAR(64), 
	lease_expires_at DATETIME, 
	annotations_json JSON NOT NULL, 
	response_hash VARCHAR(128), 
	usage_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_performance_batch_ordinal UNIQUE (performance_plan_id, ordinal), 
	FOREIGN KEY(performance_plan_id) REFERENCES performance_plans (id) ON DELETE CASCADE
);
CREATE TABLE performance_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	base_signature VARCHAR(128) NOT NULL, 
	settings_json JSON NOT NULL, 
	units_json JSON NOT NULL, 
	manual_annotations_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	version INTEGER NOT NULL, 
	job_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	adopted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE
);
CREATE TABLE project_folder_memberships (
	folder_id VARCHAR(36) NOT NULL, 
	project_session_id VARCHAR(36) NOT NULL, 
	position INTEGER NOT NULL, 
	PRIMARY KEY (folder_id, project_session_id), 
	CONSTRAINT ck_project_folder_membership_position CHECK (position >= 0), 
	FOREIGN KEY(folder_id) REFERENCES project_folders (id) ON DELETE CASCADE, 
	FOREIGN KEY(project_session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
INSERT INTO "project_folder_memberships" VALUES('2da11486-5ab6-4a3a-a392-70709a16f2a2','8203a868-0859-486c-8a96-3924746866be',0);
INSERT INTO "project_folder_memberships" VALUES('b4cca39f-4715-45bd-ab86-c5c1fe3ca24b','8203a868-0859-486c-8a96-3924746866be',1);
CREATE TABLE project_folders (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(128) NOT NULL, 
	parent_id VARCHAR(36), 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(parent_id) REFERENCES project_folders (id) ON DELETE RESTRICT
);
INSERT INTO "project_folders" VALUES('2da11486-5ab6-4a3a-a392-70709a16f2a2','Synthetic Parent',NULL,1,'2026-10-30 06:34:39.551507','2026-10-30 06:34:39.551511');
INSERT INTO "project_folders" VALUES('b4cca39f-4715-45bd-ab86-c5c1fe3ca24b','Synthetic Child','2da11486-5ab6-4a3a-a392-70709a16f2a2',1,'2026-10-30 06:34:39.552220','2026-10-30 06:34:39.552224');
CREATE TABLE project_sound_cues (
	id VARCHAR(36) NOT NULL, 
	logical_id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	variant_id VARCHAR(36) NOT NULL, 
	anchor_json JSON NOT NULL, 
	playback_json JSON NOT NULL, 
	included BOOLEAN NOT NULL, 
	placement_status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_project_sound_cue_logical UNIQUE (plan_id, logical_id), 
	CONSTRAINT ck_project_sound_cue_placement CHECK (placement_status IN ('ready', 'needs_placement')), 
	FOREIGN KEY(plan_id) REFERENCES project_sound_plans (id) ON DELETE CASCADE, 
	FOREIGN KEY(variant_id) REFERENCES sound_variants (id) ON DELETE RESTRICT
);
CREATE TABLE project_sound_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	revision INTEGER NOT NULL, 
	speech_plan_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_project_sound_plan_revision UNIQUE (session_id, revision), 
	CONSTRAINT ck_project_sound_plan_revision_positive CHECK (revision >= 1), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(speech_plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE SET NULL
);
CREATE TABLE pronunciation_entries (
	id VARCHAR(36) NOT NULL, 
	scope VARCHAR(16) NOT NULL, 
	session_id VARCHAR(36), 
	source_form TEXT NOT NULL, 
	normalized_form VARCHAR(512) NOT NULL, 
	language VARCHAR(40) NOT NULL, 
	phonetic TEXT NOT NULL, 
	alphabet VARCHAR(32) NOT NULL, 
	backend VARCHAR(80) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	source VARCHAR(40) NOT NULL, 
	notes TEXT, 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_pronunciation_entry_identity UNIQUE (scope, session_id, normalized_form, language, backend), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE "provider_models" (
	id VARCHAR(36) NOT NULL, 
	provider_id VARCHAR(36) NOT NULL, 
	model_id VARCHAR(255) NOT NULL, 
	is_active BOOLEAN DEFAULT 0 NOT NULL, 
	is_default BOOLEAN NOT NULL, 
	default_temperature FLOAT, 
	default_reasoning_effort VARCHAR(80), 
	input_cost_per_million FLOAT, 
	cached_input_cost_per_million FLOAT, 
	output_cost_per_million FLOAT, 
	context_window_tokens INTEGER NOT NULL, 
	max_output_tokens INTEGER, 
	input_modalities_json JSON NOT NULL, 
	output_modalities_json JSON NOT NULL, 
	options_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_provider_model UNIQUE (provider_id, model_id), 
	FOREIGN KEY(provider_id) REFERENCES providers (id) ON DELETE CASCADE
);
CREATE TABLE providers (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	provider_key VARCHAR(80) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	base_url TEXT, 
	secret_ref VARCHAR(255), 
	options_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_provider_identity UNIQUE (kind, provider_key, label)
);
CREATE TABLE quick_transcriptions (
	id VARCHAR(36) NOT NULL, 
	owner_subject VARCHAR(255) NOT NULL, 
	job_id VARCHAR(36), 
	source_suffix VARCHAR(16) NOT NULL, 
	size_bytes INTEGER NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	uploaded_bytes INTEGER NOT NULL, 
	next_chunk_index INTEGER NOT NULL, 
	format VARCHAR(8) NOT NULL, 
	settings_json JSON NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (job_id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE research_cache_entries (
	cache_key VARCHAR(64) NOT NULL, 
	provider VARCHAR(40) NOT NULL, 
	operation VARCHAR(40) NOT NULL, 
	request_json JSON NOT NULL, 
	response_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (cache_key)
);
CREATE TABLE resource_claims (
	resource_key VARCHAR(160) NOT NULL, 
	job_id VARCHAR(36) NOT NULL, 
	lease_owner VARCHAR(120) NOT NULL, 
	lease_generation INTEGER NOT NULL, 
	expires_at DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (resource_key), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE CASCADE
);
CREATE TABLE segment_lineage (
	parent_segment_id VARCHAR(36) NOT NULL, 
	child_segment_id VARCHAR(36) NOT NULL, 
	relation VARCHAR(40) NOT NULL, 
	sequence INTEGER NOT NULL, 
	PRIMARY KEY (parent_segment_id, child_segment_id), 
	FOREIGN KEY(parent_segment_id) REFERENCES segments (id) ON DELETE CASCADE, 
	FOREIGN KEY(child_segment_id) REFERENCES segments (id) ON DELETE CASCADE
);
CREATE TABLE segments (
	id VARCHAR(36) NOT NULL, 
	revision_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	node_kind VARCHAR(40) NOT NULL, 
	start_ms INTEGER, 
	end_ms INTEGER, 
	text TEXT NOT NULL, 
	speaker VARCHAR(160), 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_revision_segment_ordinal UNIQUE (revision_id, ordinal), 
	FOREIGN KEY(revision_id) REFERENCES document_revisions (id) ON DELETE CASCADE
);
INSERT INTO "segments" VALUES('ac252ac0-461b-42fa-9f49-ade56f0fb068','2a7da01e-066c-4104-88e3-b464ff8b8b55',0,'subtitle_cue',0,1000,'A synthetic migration check.',NULL,'{}');
CREATE TABLE session_purges (
	session_id VARCHAR(36) NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	manifest_json JSON NOT NULL, 
	expected_revision INTEGER NOT NULL, 
	impact_token VARCHAR(64) NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id)
);
CREATE TABLE session_settings (
	session_id VARCHAR(36) NOT NULL, 
	section VARCHAR(80) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id, section), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
INSERT INTO "session_settings" VALUES('8203a868-0859-486c-8a96-3924746866be','tts','{"voice_mode_version": 1, "max_sentence_length": 1800}',1,'2026-10-30 06:34:39.557654');
CREATE TABLE session_settings_history (
	id INTEGER NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	section VARCHAR(80) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE session_sources (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_asset_id VARCHAR(36) NOT NULL, 
	role VARCHAR(80) NOT NULL, 
	is_current BOOLEAN NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_session_source_attachment UNIQUE (session_id, source_asset_id, role), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_asset_id) REFERENCES source_assets (id) ON DELETE RESTRICT
);
CREATE TABLE session_stage_selections (
	session_id VARCHAR(36) NOT NULL, 
	stage_key VARCHAR(80) NOT NULL, 
	artifact_id VARCHAR(36), 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id, stage_key), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
INSERT INTO "session_stage_selections" VALUES('8203a868-0859-486c-8a96-3924746866be','transcribe','f23b756e-d7ff-4760-baa0-76eea3502725',1,'2026-10-30 06:34:39.540577');
CREATE TABLE sessions (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	storage_key VARCHAR(36) NOT NULL, 
	legacy_name VARCHAR(255), 
	legacy_path TEXT, 
	workflow_kind VARCHAR(32) NOT NULL, 
	interface_mode VARCHAR(16) DEFAULT 'advanced' NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40), 
	workflow_preset VARCHAR(64) NOT NULL, 
	included_stages_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	trashed_at DATETIME, 
	purge_after DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (storage_key)
);
INSERT INTO "sessions" VALUES('8203a868-0859-486c-8a96-3924746866be','Synthetic upgrade source','75f036dd-a561-4aa1-9a8a-54c5e22612be',NULL,NULL,'subtitles','simple','en',NULL,'custom','[]','idle',1,'2026-10-30 06:34:39.485208','2026-10-30 06:34:39.485214',NULL,NULL);
INSERT INTO "sessions" VALUES('f22502ec-9926-4658-888e-f71123455fd3','Synthetic upgrade Polish branch','70135c3b-440e-4aae-9e2c-6f2b13ccf0b1',NULL,NULL,'subtitles','simple','en','pl','custom','[]','idle',1,'2026-10-30 06:34:39.499199','2026-10-30 06:34:39.499205',NULL,NULL);
CREATE TABLE sound_items (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	tags_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	archived BOOLEAN NOT NULL, 
	preferred_variant_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(preferred_variant_id) REFERENCES sound_variants (id) ON DELETE RESTRICT
);
CREATE TABLE sound_variants (
	id VARCHAR(36) NOT NULL, 
	item_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	state VARCHAR(16) NOT NULL, 
	fingerprint VARCHAR(64), 
	provenance_json JSON NOT NULL, 
	sample_rate INTEGER, 
	channels INTEGER, 
	frame_count INTEGER, 
	duration_seconds FLOAT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(item_id) REFERENCES sound_items (id) ON DELETE RESTRICT, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE RESTRICT, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
CREATE TABLE source_assets (
	id VARCHAR(36) NOT NULL, 
	artifact_id VARCHAR(36), 
	display_name VARCHAR(255) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	mime_type VARCHAR(160), 
	external_path TEXT, 
	size_bytes INTEGER, 
	content_hash VARCHAR(128), 
	state VARCHAR(32) NOT NULL, 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE source_cleaning_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	phase VARCHAR(80) NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_source_cleaning_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES source_cleaning_dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE source_cleaning_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	job_id VARCHAR(36), 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_format VARCHAR(16) NOT NULL, 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	baseline_artifact_id VARCHAR(36), 
	index_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	accepted_operation_count INTEGER NOT NULL, 
	rejected_proposal_count INTEGER NOT NULL, 
	validation_json JSON NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(baseline_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(index_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE sources (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	display_name VARCHAR(255) NOT NULL, 
	artifact_id VARCHAR(36), 
	external_path TEXT, 
	content_hash VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE speech_optimization_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_speech_optimization_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES speech_optimization_dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE speech_optimization_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_format VARCHAR(16) NOT NULL, 
	language VARCHAR(40) NOT NULL, 
	voice_language VARCHAR(40), 
	tts_service VARCHAR(80), 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	result_revision_id VARCHAR(36), 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL
);
CREATE TABLE speech_plan_reviews (
	revision_id VARCHAR(36) NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	reviewed_at DATETIME NOT NULL, 
	PRIMARY KEY (revision_id), 
	FOREIGN KEY(revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE
);
CREATE TABLE stage_runs (
	id VARCHAR(36) NOT NULL, 
	workflow_run_id VARCHAR(36) NOT NULL, 
	stage_key VARCHAR(80) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	artifact_id VARCHAR(36), 
	detail TEXT, 
	started_at DATETIME, 
	finished_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_workflow_stage UNIQUE (workflow_run_id, stage_key), 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE stored_credentials (
	"key" VARCHAR(255) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	secret_value TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY ("key")
);
CREATE TABLE subtitle_evidence (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_media_artifact_id VARCHAR(36), 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_segment_id VARCHAR(36), 
	cue_id INTEGER NOT NULL, 
	start_ms INTEGER NOT NULL, 
	end_ms INTEGER NOT NULL, 
	clip_start_ms INTEGER NOT NULL, 
	clip_end_ms INTEGER NOT NULL, 
	reason TEXT NOT NULL, 
	routes_json JSON NOT NULL, 
	audio_model_ids_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	job_id VARCHAR(36), 
	clip_artifact_id VARCHAR(36), 
	candidates_json JSON NOT NULL, 
	resolution_json JSON NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_media_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_segment_id) REFERENCES segments (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(clip_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE timed_words (
	id VARCHAR(36) NOT NULL, 
	revision_id VARCHAR(36) NOT NULL, 
	segment_id VARCHAR(36), 
	ordinal INTEGER NOT NULL, 
	text TEXT NOT NULL, 
	start_ms INTEGER NOT NULL, 
	end_ms INTEGER NOT NULL, 
	speaker VARCHAR(160), 
	confidence FLOAT, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_timed_word_ordinal UNIQUE (revision_id, ordinal), 
	FOREIGN KEY(revision_id) REFERENCES document_revisions (id) ON DELETE CASCADE, 
	FOREIGN KEY(segment_id) REFERENCES segments (id) ON DELETE SET NULL
);
CREATE TABLE training_runs (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	voice_id VARCHAR(36), 
	job_id VARCHAR(36), 
	source_artifact_id VARCHAR(36), 
	source_text_artifact_id VARCHAR(36), 
	output_artifact_id VARCHAR(36), 
	model_name VARCHAR(255) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE SET NULL, 
	UNIQUE (job_id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_text_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(output_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE translation_project_branches (
	id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	target_language VARCHAR(40) NOT NULL, 
	source_checkpoint_artifact_id VARCHAR(36) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_translation_project_language UNIQUE (project_id, target_language), 
	FOREIGN KEY(project_id) REFERENCES translation_projects (id) ON DELETE CASCADE, 
	UNIQUE (session_id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_checkpoint_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
INSERT INTO "translation_project_branches" VALUES('6f0cd3b2-a148-42b2-a214-7aa1d199f731','7a07abc1-06fb-4e35-9dda-9fa818c084c6','f22502ec-9926-4658-888e-f71123455fd3','pl','f23b756e-d7ff-4760-baa0-76eea3502725','8903877cc47a6e3c1e5b9f2888c75879d40c82938cad5c20f36d7edfb8973eb5','2026-10-30 06:34:39.550025');
CREATE TABLE translation_project_operations (
	id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(255) NOT NULL, 
	target_instance_id VARCHAR(255) NOT NULL, 
	action VARCHAR(24) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	preview_digest VARCHAR(64) NOT NULL, 
	preview_json JSON NOT NULL, 
	children_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	cancel_requested BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES translation_projects (id) ON DELETE CASCADE
);
CREATE TABLE translation_projects (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	source_session_id VARCHAR(36) NOT NULL, 
	checkpoint_artifact_id VARCHAR(36) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	source_media_edit_revision_id VARCHAR(36), 
	source_media_edit_content_hash VARCHAR(128), 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (source_session_id), 
	FOREIGN KEY(source_session_id) REFERENCES sessions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(checkpoint_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
INSERT INTO "translation_projects" VALUES('7a07abc1-06fb-4e35-9dda-9fa818c084c6','Synthetic upgrade translation','8203a868-0859-486c-8a96-3924746866be','f23b756e-d7ff-4760-baa0-76eea3502725','8903877cc47a6e3c1e5b9f2888c75879d40c82938cad5c20f36d7edfb8973eb5','en',NULL,NULL,1,'2026-10-30 06:34:39.548210','2026-10-30 06:34:39.548215');
CREATE TABLE upload_sessions (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36), 
	filename VARCHAR(255) NOT NULL, 
	mime_type VARCHAR(160), 
	size_bytes INTEGER NOT NULL, 
	chunk_size INTEGER NOT NULL, 
	chunk_count INTEGER NOT NULL, 
	received_json JSON NOT NULL, 
	expected_hash VARCHAR(128), 
	temporary_relative_path TEXT NOT NULL, 
	state VARCHAR(32) NOT NULL, 
	result_json JSON, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE usage_events (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36), 
	workflow_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	generation_run_id VARCHAR(36), 
	agent_run_id VARCHAR(36), 
	request_key VARCHAR(200), 
	stage VARCHAR(80), 
	provider_key VARCHAR(80) NOT NULL, 
	model_id VARCHAR(255) NOT NULL, 
	input_tokens INTEGER NOT NULL, 
	cached_input_tokens INTEGER NOT NULL, 
	output_tokens INTEGER NOT NULL, 
	cost_usd FLOAT, 
	cost_source VARCHAR(40), 
	raw_usage_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_usage_event_agent_request UNIQUE (agent_run_id, request_key), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE SET NULL, 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(agent_run_id) REFERENCES agent_runs (id) ON DELETE SET NULL
);
CREATE TABLE voice_catalog_overrides (
	voice_key VARCHAR(1024) NOT NULL, 
	voice_ref_json JSON NOT NULL, 
	name VARCHAR(255), 
	description TEXT, 
	voice_category VARCHAR(20), 
	profile_json JSON, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (voice_key)
);
CREATE TABLE voice_collection_members (
	collection_id VARCHAR(36) NOT NULL, 
	voice_key VARCHAR(1024) NOT NULL, 
	voice_ref_json JSON NOT NULL, 
	managed_voice_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (collection_id, voice_key), 
	FOREIGN KEY(collection_id) REFERENCES voice_collections (id) ON DELETE CASCADE, 
	FOREIGN KEY(managed_voice_id) REFERENCES voices (id) ON DELETE CASCADE
);
CREATE TABLE voice_collections (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	description TEXT, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
CREATE TABLE voice_samples (
	id VARCHAR(36) NOT NULL, 
	voice_id VARCHAR(36) NOT NULL, 
	artifact_id VARCHAR(36) NOT NULL, 
	transcript TEXT, 
	transcript_language VARCHAR(40), 
	transcript_reviewed BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
CREATE TABLE voices (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	language VARCHAR(40), 
	description TEXT, 
	rvc_model_ref VARCHAR(255), 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
CREATE TABLE workflow_execution_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(200) NOT NULL, 
	target_instance_id VARCHAR(36) NOT NULL, 
	plan_digest VARCHAR(64) NOT NULL, 
	plan_json JSON NOT NULL, 
	state_fingerprint VARCHAR(64) NOT NULL, 
	required_confirmations_json JSON NOT NULL, 
	resulting_job_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	consumed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(resulting_job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE workflow_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	preset VARCHAR(64) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE INDEX ix_app_settings_history_key ON app_settings_history ("key");
CREATE INDEX ix_sessions_purge_after ON sessions (purge_after);
CREATE INDEX ix_sessions_legacy_name ON sessions (legacy_name);
CREATE INDEX ix_sessions_updated_at ON sessions (updated_at);
CREATE INDEX ix_sessions_status ON sessions (status);
CREATE INDEX ix_project_folders_parent_id ON project_folders (parent_id);
CREATE INDEX ix_research_cache_entries_operation ON research_cache_entries (operation);
CREATE INDEX ix_research_cache_entries_expires_at ON research_cache_entries (expires_at);
CREATE INDEX ix_research_cache_entries_provider ON research_cache_entries (provider);
CREATE INDEX ix_automation_clients_revoked_at ON automation_clients (revoked_at);
CREATE INDEX ix_audit_events_principal_subject ON audit_events (principal_subject);
CREATE INDEX ix_audit_events_action ON audit_events (action);
CREATE INDEX ix_audit_events_request_id ON audit_events (request_id);
CREATE INDEX ix_audit_events_outcome ON audit_events (outcome);
CREATE INDEX ix_audit_events_resource_id ON audit_events (resource_id);
CREATE INDEX ix_audit_events_created_at ON audit_events (created_at);
CREATE INDEX ix_audit_events_plan_id ON audit_events (plan_id);
CREATE INDEX ix_audit_events_idempotency_key ON audit_events (idempotency_key);
CREATE INDEX ix_api_idempotency_expires_at ON api_idempotency (expires_at);
CREATE INDEX ix_api_idempotency_resource_id ON api_idempotency (resource_id);
CREATE INDEX ix_capability_snapshots_created_at ON capability_snapshots (created_at);
CREATE INDEX ix_sound_items_archived_created_at_id ON sound_items (archived, created_at, id);
CREATE INDEX ix_sound_variants_fingerprint_state ON sound_variants (fingerprint, state);
CREATE INDEX ix_sound_variants_item_created_at_id ON sound_variants (item_id, created_at, id);
CREATE INDEX ix_project_folder_memberships_project_session_id ON project_folder_memberships (project_session_id);
CREATE INDEX ix_session_settings_history_session_id ON session_settings_history (session_id);
CREATE INDEX ix_outcome_plan_history_session_id ON outcome_plan_history (session_id);
CREATE INDEX ix_artifacts_session_id ON artifacts (session_id);
CREATE INDEX ix_artifacts_content_hash ON artifacts (content_hash);
CREATE INDEX idx_artifacts_session_role_created ON artifacts (session_id, role, created_at DESC, id DESC);
CREATE INDEX ix_artifacts_kind ON artifacts (kind);
CREATE INDEX ix_documents_session_id ON documents (session_id);
CREATE UNIQUE INDEX ix_generation_plans_session_id ON generation_plans (session_id);
CREATE UNIQUE INDEX ix_media_edit_plans_session_id ON media_edit_plans (session_id);
CREATE INDEX ix_upload_sessions_state ON upload_sessions (state);
CREATE INDEX ix_upload_sessions_expires_at ON upload_sessions (expires_at);
CREATE INDEX ix_upload_sessions_session_id ON upload_sessions (session_id);
CREATE INDEX ix_knowledge_ledgers_session_id ON knowledge_ledgers (session_id);
CREATE INDEX ix_pronunciation_entries_status ON pronunciation_entries (status);
CREATE INDEX ix_pronunciation_entries_backend ON pronunciation_entries (backend);
CREATE INDEX ix_pronunciation_entries_language ON pronunciation_entries (language);
CREATE INDEX ix_pronunciation_entries_scope ON pronunciation_entries (scope);
CREATE INDEX ix_pronunciation_entries_normalized_form ON pronunciation_entries (normalized_form);
CREATE INDEX ix_pronunciation_entries_session_id ON pronunciation_entries (session_id);
CREATE INDEX ix_automation_enrollment_grants_client_id ON automation_enrollment_grants (client_id);
CREATE INDEX ix_automation_enrollment_grants_code_prefix ON automation_enrollment_grants (code_prefix);
CREATE INDEX ix_automation_enrollment_grants_expires_at ON automation_enrollment_grants (expires_at);
CREATE INDEX ix_api_tokens_client_id ON api_tokens (client_id);
CREATE INDEX ix_api_tokens_subject ON api_tokens (subject);
CREATE INDEX ix_api_tokens_token_prefix ON api_tokens (token_prefix);
CREATE INDEX ix_api_tokens_expires_at ON api_tokens (expires_at);
CREATE INDEX ix_source_assets_artifact_id ON source_assets (artifact_id);
CREATE INDEX ix_source_assets_content_hash ON source_assets (content_hash);
CREATE INDEX ix_source_assets_state ON source_assets (state);
CREATE INDEX ix_jobs_available_at ON jobs (available_at);
CREATE INDEX idx_jobs_session_kind_created ON jobs (session_id, kind, created_at DESC, id DESC);
CREATE INDEX ix_jobs_kind ON jobs (kind);
CREATE INDEX idx_jobs_status_created ON jobs (status, created_at, id);
CREATE INDEX ix_jobs_session_id ON jobs (session_id);
CREATE INDEX ix_jobs_status ON jobs (status);
CREATE INDEX ix_jobs_lease_expires_at ON jobs (lease_expires_at);
CREATE INDEX ix_jobs_lease_owner ON jobs (lease_owner);
CREATE INDEX ix_jobs_created_at ON jobs (created_at);
CREATE INDEX idx_artifact_edges_child_parent ON artifact_edges (child_artifact_id, parent_artifact_id);
CREATE INDEX ix_session_stage_selections_artifact_id ON session_stage_selections (artifact_id);
CREATE INDEX ix_document_revisions_document_id ON document_revisions (document_id);
CREATE INDEX ix_media_edit_plan_revisions_parent_revision_id ON media_edit_plan_revisions (parent_revision_id);
CREATE INDEX ix_media_edit_plan_revisions_source_media_artifact_id ON media_edit_plan_revisions (source_media_artifact_id);
CREATE INDEX ix_media_edit_plan_revisions_plan_id ON media_edit_plan_revisions (plan_id);
CREATE INDEX ix_media_edit_plan_revisions_editorial_transcript_artifact_id ON media_edit_plan_revisions (editorial_transcript_artifact_id);
CREATE INDEX ix_media_edit_plan_revisions_timing_artifact_id ON media_edit_plan_revisions (timing_artifact_id);
CREATE INDEX ix_voice_samples_voice_id ON voice_samples (voice_id);
CREATE INDEX ix_translation_project_branches_project_id ON translation_project_branches (project_id);
CREATE INDEX ix_translation_project_operations_project_id ON translation_project_operations (project_id);
CREATE INDEX ix_session_sources_source_asset_id ON session_sources (source_asset_id);
CREATE INDEX ix_session_sources_session_id ON session_sources (session_id);
CREATE INDEX idx_session_sources_current_updated ON session_sources (session_id, is_current DESC, updated_at DESC, id);
CREATE INDEX ix_quick_transcriptions_owner_subject ON quick_transcriptions (owner_subject);
CREATE INDEX ix_quick_transcriptions_expires_at ON quick_transcriptions (expires_at);
CREATE INDEX ix_job_events_event_type ON job_events (event_type);
CREATE INDEX ix_job_events_created_at ON job_events (created_at);
CREATE INDEX ix_job_events_job_id ON job_events (job_id);
CREATE INDEX ix_segments_revision_id ON segments (revision_id);
CREATE INDEX idx_segments_revision_timing ON segments (revision_id, start_ms, end_ms);
CREATE INDEX ix_generation_plan_revisions_parent_revision_id ON generation_plan_revisions (parent_revision_id);
CREATE INDEX ix_generation_plan_revisions_source_revision_id ON generation_plan_revisions (source_revision_id);
CREATE INDEX ix_generation_plan_revisions_plan_id ON generation_plan_revisions (plan_id);
CREATE INDEX ix_resource_claims_lease_owner ON resource_claims (lease_owner);
CREATE INDEX ix_resource_claims_job_id ON resource_claims (job_id);
CREATE INDEX ix_resource_claims_expires_at ON resource_claims (expires_at);
CREATE INDEX ix_agent_runs_kind ON agent_runs (kind);
CREATE INDEX ix_agent_runs_status ON agent_runs (status);
CREATE INDEX ix_agent_runs_session_id ON agent_runs (session_id);
CREATE INDEX ix_agent_runs_settings_hash ON agent_runs (settings_hash);
CREATE INDEX ix_agent_runs_source_content_hash ON agent_runs (source_content_hash);
CREATE INDEX ix_dispatch_runs_created_at ON dispatch_runs (created_at);
CREATE INDEX ix_dispatch_runs_session_id ON dispatch_runs (session_id);
CREATE INDEX ix_dispatch_runs_source_revision_id ON dispatch_runs (source_revision_id);
CREATE INDEX ix_dispatch_runs_source_artifact_id ON dispatch_runs (source_artifact_id);
CREATE INDEX ix_dispatch_runs_status ON dispatch_runs (status);
CREATE INDEX ix_dispatch_runs_updated_at ON dispatch_runs (updated_at);
CREATE INDEX ix_dispatch_runs_output_head_artifact_id ON dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_dispatch_runs_result_revision_id ON dispatch_runs (result_revision_id);
CREATE INDEX ix_dispatch_runs_result_artifact_id ON dispatch_runs (result_artifact_id);
CREATE INDEX ix_dispatch_runs_kind ON dispatch_runs (kind);
CREATE INDEX ix_source_cleaning_dispatch_runs_session_id ON source_cleaning_dispatch_runs (session_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_index_artifact_id ON source_cleaning_dispatch_runs (index_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_result_artifact_id ON source_cleaning_dispatch_runs (result_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_created_at ON source_cleaning_dispatch_runs (created_at);
CREATE INDEX ix_source_cleaning_dispatch_runs_status ON source_cleaning_dispatch_runs (status);
CREATE INDEX ix_source_cleaning_dispatch_runs_updated_at ON source_cleaning_dispatch_runs (updated_at);
CREATE INDEX ix_source_cleaning_dispatch_runs_source_artifact_id ON source_cleaning_dispatch_runs (source_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_job_id ON source_cleaning_dispatch_runs (job_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_output_head_artifact_id ON source_cleaning_dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_baseline_artifact_id ON source_cleaning_dispatch_runs (baseline_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_output_head_artifact_id ON speech_optimization_dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_status ON speech_optimization_dispatch_runs (status);
CREATE INDEX ix_speech_optimization_dispatch_runs_result_artifact_id ON speech_optimization_dispatch_runs (result_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_result_revision_id ON speech_optimization_dispatch_runs (result_revision_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_updated_at ON speech_optimization_dispatch_runs (updated_at);
CREATE INDEX ix_speech_optimization_dispatch_runs_source_artifact_id ON speech_optimization_dispatch_runs (source_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_created_at ON speech_optimization_dispatch_runs (created_at);
CREATE INDEX ix_speech_optimization_dispatch_runs_session_id ON speech_optimization_dispatch_runs (session_id);
CREATE INDEX ix_media_edit_dispatch_runs_result_revision_id ON media_edit_dispatch_runs (result_revision_id);
CREATE INDEX ix_media_edit_dispatch_runs_updated_at ON media_edit_dispatch_runs (updated_at);
CREATE INDEX ix_media_edit_dispatch_runs_created_at ON media_edit_dispatch_runs (created_at);
CREATE INDEX ix_media_edit_dispatch_runs_status ON media_edit_dispatch_runs (status);
CREATE INDEX ix_media_edit_dispatch_runs_source_revision_id ON media_edit_dispatch_runs (source_revision_id);
CREATE INDEX ix_media_edit_dispatch_runs_session_id ON media_edit_dispatch_runs (session_id);
CREATE INDEX ix_training_runs_voice_id ON training_runs (voice_id);
CREATE INDEX ix_training_runs_status ON training_runs (status);
CREATE INDEX ix_exports_session_id ON exports (session_id);
CREATE INDEX ix_workflow_execution_plans_expires_at ON workflow_execution_plans (expires_at);
CREATE INDEX ix_workflow_execution_plans_session_id ON workflow_execution_plans (session_id);
CREATE INDEX ix_workflow_execution_plans_consumed_at ON workflow_execution_plans (consumed_at);
CREATE INDEX ix_workflow_execution_plans_resulting_job_id ON workflow_execution_plans (resulting_job_id);
CREATE INDEX ix_workflow_execution_plans_principal_subject ON workflow_execution_plans (principal_subject);
CREATE INDEX ix_workflow_execution_plans_plan_digest ON workflow_execution_plans (plan_digest);
CREATE INDEX ix_subtitle_evidence_status ON subtitle_evidence (status);
CREATE INDEX ix_subtitle_evidence_source_artifact_id ON subtitle_evidence (source_artifact_id);
CREATE INDEX ix_subtitle_evidence_clip_artifact_id ON subtitle_evidence (clip_artifact_id);
CREATE INDEX ix_subtitle_evidence_source_media_artifact_id ON subtitle_evidence (source_media_artifact_id);
CREATE INDEX ix_subtitle_evidence_source_revision_id ON subtitle_evidence (source_revision_id);
CREATE INDEX ix_subtitle_evidence_session_id ON subtitle_evidence (session_id);
CREATE UNIQUE INDEX ix_subtitle_evidence_job_id ON subtitle_evidence (job_id);
CREATE INDEX ix_subtitle_evidence_source_segment_id ON subtitle_evidence (source_segment_id);
CREATE INDEX ix_segment_lineage_child_segment_id ON segment_lineage (child_segment_id);
CREATE INDEX ix_timed_words_revision_id ON timed_words (revision_id);
CREATE INDEX ix_timed_words_segment_id ON timed_words (segment_id);
CREATE INDEX ix_generation_runs_source_generation_run_id ON generation_runs (source_generation_run_id);
CREATE INDEX ix_generation_runs_status ON generation_runs (status);
CREATE INDEX ix_generation_runs_job_id ON generation_runs (job_id);
CREATE INDEX ix_generation_runs_output_generation_run_id ON generation_runs (output_generation_run_id);
CREATE INDEX ix_generation_runs_plan_revision_id ON generation_runs (plan_revision_id);
CREATE INDEX ix_generation_runs_session_id ON generation_runs (session_id);
CREATE INDEX ix_performance_plans_plan_revision_id ON performance_plans (plan_revision_id);
CREATE INDEX ix_performance_plans_status ON performance_plans (status);
CREATE INDEX ix_performance_plans_session_id ON performance_plans (session_id);
CREATE INDEX ix_generation_segments_status ON generation_segments (status);
CREATE INDEX ix_generation_segments_revision_removed_status ON generation_segments (plan_revision_id, removed, status);
CREATE INDEX ix_generation_segments_plan_revision_id ON generation_segments (plan_revision_id);
CREATE INDEX ix_generation_segments_optimization_status ON generation_segments (optimization_status);
CREATE INDEX ix_generation_segments_alignment_group ON generation_segments (alignment_group);
CREATE INDEX ix_generation_segments_voice_id ON generation_segments (voice_id);
CREATE INDEX ix_generation_segments_marked ON generation_segments (marked);
CREATE INDEX ix_dispatch_batches_dispatch_run_id ON dispatch_batches (dispatch_run_id);
CREATE INDEX ix_dispatch_batches_lease_expires_at ON dispatch_batches (lease_expires_at);
CREATE INDEX ix_dispatch_batches_status ON dispatch_batches (status);
CREATE INDEX ix_source_cleaning_dispatch_batches_status ON source_cleaning_dispatch_batches (status);
CREATE INDEX ix_source_cleaning_dispatch_batches_phase ON source_cleaning_dispatch_batches (phase);
CREATE INDEX ix_source_cleaning_dispatch_batches_lease_expires_at ON source_cleaning_dispatch_batches (lease_expires_at);
CREATE INDEX ix_source_cleaning_dispatch_batches_dispatch_run_id ON source_cleaning_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_speech_optimization_dispatch_batches_dispatch_run_id ON speech_optimization_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_speech_optimization_dispatch_batches_lease_expires_at ON speech_optimization_dispatch_batches (lease_expires_at);
CREATE INDEX ix_speech_optimization_dispatch_batches_status ON speech_optimization_dispatch_batches (status);
CREATE INDEX ix_media_edit_dispatch_batches_dispatch_run_id ON media_edit_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_media_edit_dispatch_batches_lease_expires_at ON media_edit_dispatch_batches (lease_expires_at);
CREATE INDEX ix_media_edit_dispatch_batches_status ON media_edit_dispatch_batches (status);
CREATE INDEX ix_agent_steps_agent_run_id ON agent_steps (agent_run_id);
CREATE INDEX ix_performance_batches_performance_plan_id ON performance_batches (performance_plan_id);
CREATE INDEX ix_performance_batches_status ON performance_batches (status);
CREATE INDEX ix_generation_segment_revisions_generation_segment_id ON generation_segment_revisions (generation_segment_id);
CREATE INDEX ix_audio_takes_generation_segment_id ON audio_takes (generation_segment_id);
CREATE INDEX ix_audio_takes_artifact_id ON audio_takes (artifact_id);
CREATE INDEX ix_audio_takes_parent_take_id ON audio_takes (parent_take_id);
CREATE INDEX ix_audio_takes_status ON audio_takes (status);
CREATE INDEX ix_audio_takes_generation_run_id ON audio_takes (generation_run_id);
CREATE INDEX idx_audio_takes_active_status_segment_created ON audio_takes (is_active, status, generation_segment_id, created_at DESC, id DESC);
CREATE INDEX idx_output_assemblies_session_created ON output_assemblies (session_id, created_at DESC, id DESC);
CREATE INDEX ix_output_assemblies_generation_run_id ON output_assemblies (generation_run_id);
CREATE INDEX ix_output_assemblies_session_id ON output_assemblies (session_id);
CREATE INDEX ix_output_assemblies_job_id ON output_assemblies (job_id);
CREATE INDEX ix_usage_events_agent_run_id ON usage_events (agent_run_id);
CREATE INDEX ix_usage_events_artifact_id ON usage_events (artifact_id);
CREATE INDEX ix_usage_events_job_id ON usage_events (job_id);
CREATE INDEX ix_usage_events_session_id ON usage_events (session_id);
CREATE INDEX ix_usage_events_created_at ON usage_events (created_at);
CREATE INDEX ix_usage_events_generation_run_id ON usage_events (generation_run_id);
CREATE INDEX idx_usage_events_session_stage_created ON usage_events (session_id, stage, created_at DESC, id DESC);
CREATE UNIQUE INDEX uq_generation_run_sequence ON generation_runs (session_id, sequence_number);
CREATE INDEX ix_project_sound_plans_session_revision ON project_sound_plans (session_id, revision);
CREATE INDEX ix_project_sound_cues_plan_logical ON project_sound_cues (plan_id, logical_id);
COMMIT;
