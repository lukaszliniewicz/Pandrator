BEGIN TRANSACTION;
CREATE TABLE agent_runs (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(80) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	job_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	source_content_hash VARCHAR(128), 
	settings_hash VARCHAR(128), 
	checkpoint_revision INTEGER NOT NULL, 
	error_message TEXT, 
	settings_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE agent_steps (
	id VARCHAR(36) NOT NULL, 
	agent_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	unit_key VARCHAR(160), 
	input_hash VARCHAR(128), 
	phase VARCHAR(80) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	summary TEXT, 
	input_json JSON NOT NULL, 
	output_json JSON NOT NULL, 
	cost_usd FLOAT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_agent_step_unit_key UNIQUE (agent_run_id, unit_key), 
	FOREIGN KEY(agent_run_id) REFERENCES agent_runs (id) ON DELETE CASCADE, 
	CONSTRAINT uq_agent_step_ordinal UNIQUE (agent_run_id, ordinal)
);
CREATE TABLE alembic_version (
	version_num VARCHAR(32) NOT NULL, 
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
INSERT INTO "alembic_version" VALUES('0082_private_transcription_owners');
CREATE TABLE api_idempotency (
	id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(200) NOT NULL, 
	operation_id VARCHAR(160) NOT NULL, 
	idempotency_key VARCHAR(200) NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	status_code INTEGER, 
	response_json JSON, 
	resource_kind VARCHAR(80), 
	resource_id VARCHAR(160), 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_api_idempotency_principal_operation_key UNIQUE (principal_subject, operation_id, idempotency_key)
);
CREATE TABLE api_token_project_grants (
	token_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (token_id, project_id), 
	CONSTRAINT fk_api_token_project_grants_token_id FOREIGN KEY(token_id) REFERENCES api_tokens (id) ON DELETE CASCADE, 
	CONSTRAINT fk_api_token_project_grants_project_id FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE
);
CREATE TABLE api_token_workspace_grants (
	token_id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (token_id, workspace_id), 
	CONSTRAINT fk_api_token_workspace_grants_token_id FOREIGN KEY(token_id) REFERENCES api_tokens (id) ON DELETE CASCADE, 
	CONSTRAINT fk_api_token_workspace_grants_workspace_id FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE
);
CREATE TABLE api_tokens (
	id VARCHAR(36) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	token_hash VARCHAR(128) NOT NULL, 
	token_prefix VARCHAR(16) NOT NULL, 
	subject VARCHAR(200), 
	scopes_json JSON NOT NULL, 
	expires_at DATETIME, 
	principal_kind VARCHAR(40) NOT NULL, 
	created_by VARCHAR(200), 
	user_id VARCHAR(36), 
	user_auth_revision INTEGER, 
	client_id VARCHAR(36), 
	target_instance_id VARCHAR(36), 
	canonical_origin TEXT, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	CONSTRAINT fk_api_tokens_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE SET NULL, 
	CONSTRAINT ck_api_tokens_user_auth_pair CHECK ((user_id IS NULL AND user_auth_revision IS NULL) OR (user_id IS NOT NULL AND user_auth_revision IS NOT NULL AND user_auth_revision >= 1))
);
CREATE TABLE app_settings (
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY ("key")
);
CREATE TABLE app_settings_history (
	id INTEGER NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE artifact_edges (
	parent_artifact_id VARCHAR(36) NOT NULL, 
	child_artifact_id VARCHAR(36) NOT NULL, 
	relation VARCHAR(80) NOT NULL, 
	PRIMARY KEY (parent_artifact_id, child_artifact_id), 
	FOREIGN KEY(child_artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_artifact_id) REFERENCES artifacts (id) ON DELETE CASCADE
);
CREATE TABLE "artifacts" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	session_id VARCHAR(36), 
	kind VARCHAR(80) NOT NULL, 
	role VARCHAR(120) NOT NULL, 
	relative_path TEXT NOT NULL, 
	mime_type VARCHAR(160), 
	size_bytes INTEGER, 
	content_hash VARCHAR(128), 
	state VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_artifacts_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_artifacts_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE SET NULL, 
	CONSTRAINT uq_artifact_relative_path UNIQUE (relative_path), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE audio_takes (
	id VARCHAR(36) NOT NULL, 
	generation_segment_id VARCHAR(36) NOT NULL, 
	generation_run_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	parent_take_id VARCHAR(36), 
	kind VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	duration_ms INTEGER, 
	is_active BOOLEAN NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(parent_take_id) REFERENCES audio_takes (id) ON DELETE SET NULL, 
	FOREIGN KEY(generation_segment_id) REFERENCES generation_segments (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE CASCADE
);
CREATE TABLE audit_actors (
	audit_event_id INTEGER NOT NULL, 
	user_id VARCHAR(36), 
	auth_revision INTEGER, 
	context_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (audit_event_id), 
	CONSTRAINT ck_audit_actors_user_auth_pair CHECK ((user_id IS NULL AND auth_revision IS NULL) OR (user_id IS NOT NULL AND auth_revision IS NOT NULL AND auth_revision >= 1)), 
	CONSTRAINT fk_audit_actors_audit_event_id_audit_events FOREIGN KEY(audit_event_id) REFERENCES audit_events (id) ON DELETE CASCADE, 
	CONSTRAINT fk_audit_actors_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE TABLE audit_events (
	id INTEGER NOT NULL, 
	request_id VARCHAR(80) NOT NULL, 
	traceparent VARCHAR(80), 
	principal_subject VARCHAR(200) NOT NULL, 
	principal_kind VARCHAR(40) NOT NULL, 
	scopes_json JSON NOT NULL, 
	action VARCHAR(160) NOT NULL, 
	method VARCHAR(12) NOT NULL, 
	path VARCHAR(500) NOT NULL, 
	idempotency_key VARCHAR(200), 
	plan_id VARCHAR(120), 
	plan_digest VARCHAR(128), 
	resource_kind VARCHAR(80), 
	resource_id VARCHAR(160), 
	outcome VARCHAR(40) NOT NULL, 
	status_code INTEGER NOT NULL, 
	duration_ms INTEGER NOT NULL, 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE automation_client_project_grants (
	client_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (client_id, project_id), 
	CONSTRAINT fk_automation_client_project_grants_client_id FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE CASCADE, 
	CONSTRAINT fk_automation_client_project_grants_project_id FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE
);
CREATE TABLE automation_client_workspace_grants (
	client_id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (client_id, workspace_id), 
	CONSTRAINT fk_automation_client_workspace_grants_client_id FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE CASCADE, 
	CONSTRAINT fk_automation_client_workspace_grants_workspace_id FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE
);
CREATE TABLE automation_clients (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(160) NOT NULL, 
	subject VARCHAR(200) NOT NULL, 
	redirect_uris_json JSON NOT NULL, 
	allowed_scopes_json JSON NOT NULL, 
	target_instance_id VARCHAR(36) NOT NULL, 
	canonical_origin TEXT NOT NULL, 
	created_by VARCHAR(200) NOT NULL, 
	user_id VARCHAR(36), 
	user_auth_revision INTEGER, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (subject), 
	CONSTRAINT ck_automation_clients_user_auth_pair CHECK ((user_id IS NULL AND user_auth_revision IS NULL) OR (user_id IS NOT NULL AND user_auth_revision IS NOT NULL AND user_auth_revision >= 1)), 
	CONSTRAINT fk_automation_clients_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE TABLE automation_code_project_grants (
	code_grant_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (code_grant_id, project_id), 
	CONSTRAINT fk_automation_code_project_grants_code_grant_id FOREIGN KEY(code_grant_id) REFERENCES automation_enrollment_grants (id) ON DELETE CASCADE, 
	CONSTRAINT fk_automation_code_project_grants_project_id FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE
);
CREATE TABLE automation_code_workspace_grants (
	code_grant_id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (code_grant_id, workspace_id), 
	CONSTRAINT fk_automation_code_workspace_grants_code_grant_id FOREIGN KEY(code_grant_id) REFERENCES automation_enrollment_grants (id) ON DELETE CASCADE, 
	CONSTRAINT fk_automation_code_workspace_grants_workspace_id FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE
);
CREATE TABLE automation_enrollment_grants (
	id VARCHAR(36) NOT NULL, 
	client_id VARCHAR(36) NOT NULL, 
	code_hash VARCHAR(128) NOT NULL, 
	code_prefix VARCHAR(16) NOT NULL, 
	redirect_uri TEXT, 
	scopes_json JSON NOT NULL, 
	code_challenge VARCHAR(128) NOT NULL, 
	code_challenge_method VARCHAR(16) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	token_expires_at DATETIME NOT NULL, 
	consumed_at DATETIME, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (code_hash), 
	FOREIGN KEY(client_id) REFERENCES automation_clients (id) ON DELETE CASCADE
);
CREATE TABLE browser_auth_project_grants (
	browser_session_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (browser_session_id, project_id), 
	CONSTRAINT fk_browser_auth_project_grants_browser_session_id FOREIGN KEY(browser_session_id) REFERENCES browser_auth_sessions (id) ON DELETE CASCADE, 
	CONSTRAINT fk_browser_auth_project_grants_project_id FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE
);
CREATE TABLE browser_auth_sessions (
	id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	auth_revision INTEGER NOT NULL, 
	subject VARCHAR(200) NOT NULL, 
	principal_kind VARCHAR(40) NOT NULL, 
	scopes_json JSON NOT NULL, 
	client_id VARCHAR(200), 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	idle_expires_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_browser_auth_sessions_auth_revision CHECK (auth_revision >= 1), 
	CONSTRAINT fk_browser_auth_sessions_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_browser_auth_sessions_token_hash UNIQUE (token_hash)
);
CREATE TABLE browser_auth_workspace_grants (
	browser_session_id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (browser_session_id, workspace_id), 
	CONSTRAINT fk_browser_auth_workspace_grants_browser_session_id FOREIGN KEY(browser_session_id) REFERENCES browser_auth_sessions (id) ON DELETE CASCADE, 
	CONSTRAINT fk_browser_auth_workspace_grants_workspace_id FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE
);
CREATE TABLE capability_snapshots (
	id INTEGER NOT NULL, 
	payload_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	output_role VARCHAR(120) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40), 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	result_revision_id VARCHAR(36), 
	glossary_json JSON NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(result_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
CREATE TABLE document_revisions (
	id VARCHAR(36) NOT NULL, 
	document_id VARCHAR(36) NOT NULL, 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	reviewed BOOLEAN NOT NULL, 
	settings_hash VARCHAR(128), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(parent_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(document_id) REFERENCES documents (id) ON DELETE CASCADE, 
	CONSTRAINT uq_document_revision UNIQUE (document_id, revision_number)
);
CREATE TABLE documents (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	stage VARCHAR(80) NOT NULL, 
	language VARCHAR(40), 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE exports (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	options_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE generation_plan_revisions (
	id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36), 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	settings_json JSON NOT NULL, 
	operation_json JSON NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(plan_id) REFERENCES generation_plans (id) ON DELETE CASCADE, 
	CONSTRAINT uq_generation_plan_revision UNIQUE (plan_id, revision_number), 
	FOREIGN KEY(parent_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL
);
CREATE TABLE generation_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE generation_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	source_generation_run_id VARCHAR(36), 
	output_generation_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	sequence_number INTEGER NOT NULL, 
	operation VARCHAR(32) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	pause_requested BOOLEAN NOT NULL, 
	cancel_requested BOOLEAN NOT NULL, 
	resume_source_on_completion BOOLEAN NOT NULL, 
	settings_snapshot_json JSON NOT NULL, 
	audio_version_json JSON, 
	settings_hash VARCHAR(128), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_generation_run_sequence UNIQUE (session_id, sequence_number), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(output_generation_run_id) REFERENCES generation_runs (id) ON DELETE CASCADE, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL
);
CREATE TABLE generation_segment_revisions (
	id INTEGER NOT NULL, 
	generation_segment_id VARCHAR(36) NOT NULL, 
	revision INTEGER NOT NULL, 
	ordinal INTEGER, 
	source_segment_ids_json JSON NOT NULL, 
	speech_block_provenance_json JSON NOT NULL, 
	alignment_group VARCHAR(64), 
	node_kind VARCHAR(40) NOT NULL, 
	paragraph_break_after BOOLEAN NOT NULL, 
	speaker VARCHAR(160), 
	text TEXT NOT NULL, 
	optimized_text TEXT, 
	speech_plan_json JSON NOT NULL, 
	optimization_status VARCHAR(32) NOT NULL, 
	optimization_reviewed BOOLEAN NOT NULL, 
	marked BOOLEAN NOT NULL, 
	removed BOOLEAN NOT NULL, 
	voice_id VARCHAR(36), 
	voice VARCHAR(255), 
	language VARCHAR(40), 
	silence_after_ms INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(generation_segment_id) REFERENCES generation_segments (id) ON DELETE CASCADE
);
CREATE TABLE generation_segments (
	id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	source_segment_ids_json JSON NOT NULL, 
	speech_block_provenance_json JSON NOT NULL, 
	alignment_group VARCHAR(64), 
	node_kind VARCHAR(40) NOT NULL, 
	paragraph_break_after BOOLEAN NOT NULL, 
	speaker VARCHAR(160), 
	text TEXT NOT NULL, 
	optimized_text TEXT, 
	speech_plan_json JSON NOT NULL, 
	optimization_status VARCHAR(32) NOT NULL, 
	optimization_source_hash VARCHAR(128), 
	optimization_reviewed BOOLEAN NOT NULL, 
	optimization_model VARCHAR(255), 
	voice_id VARCHAR(36), 
	voice VARCHAR(255), 
	language VARCHAR(40), 
	silence_after_ms INTEGER NOT NULL, 
	marked BOOLEAN NOT NULL, 
	removed BOOLEAN NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE SET NULL, 
	CONSTRAINT uq_generation_segment_ordinal UNIQUE (plan_revision_id, ordinal), 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE
);
CREATE TABLE job_actors (
	job_id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36), 
	auth_revision INTEGER, 
	context_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (job_id), 
	CONSTRAINT ck_job_actors_user_auth_pair CHECK ((user_id IS NULL AND auth_revision IS NULL) OR (user_id IS NOT NULL AND auth_revision IS NOT NULL AND auth_revision >= 1)), 
	CONSTRAINT fk_job_actors_job_id_jobs FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE CASCADE, 
	CONSTRAINT fk_job_actors_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE TABLE job_events (
	id INTEGER NOT NULL, 
	job_id VARCHAR(36), 
	event_type VARCHAR(80) NOT NULL, 
	payload_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE CASCADE
);
CREATE TABLE "jobs" (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(120) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	session_id VARCHAR(36), 
	workflow_run_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	payload_json JSON NOT NULL, 
	resource_keys_json JSON NOT NULL, 
	result_json JSON, 
	progress FLOAT NOT NULL, 
	progress_detail TEXT, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	lease_owner VARCHAR(120), 
	lease_expires_at DATETIME, 
	lease_generation INTEGER NOT NULL, 
	available_at DATETIME, 
	attempts INTEGER NOT NULL, 
	max_attempts INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME, 
	finished_at DATETIME, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_jobs_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_jobs_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE RESTRICT, 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE knowledge_ledgers (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40) NOT NULL, 
	payload_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	CONSTRAINT uq_knowledge_ledger_scope UNIQUE (session_id, kind, source_language, target_language)
);
CREATE TABLE media_edit_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(dispatch_run_id) REFERENCES media_edit_dispatch_runs (id) ON DELETE CASCADE, 
	CONSTRAINT uq_media_edit_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal)
);
CREATE TABLE media_edit_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_revision_number INTEGER NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	instructions TEXT NOT NULL, 
	settings_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	result_revision_id VARCHAR(36), 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(result_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE RESTRICT
);
CREATE TABLE media_edit_plan_revisions (
	id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	parent_revision_id VARCHAR(36), 
	revision_number INTEGER NOT NULL, 
	source_media_artifact_id VARCHAR(36) NOT NULL, 
	editorial_transcript_artifact_id VARCHAR(36) NOT NULL, 
	timing_artifact_id VARCHAR(36), 
	duration_ms INTEGER NOT NULL, 
	instructions TEXT NOT NULL, 
	keep_ranges_json JSON NOT NULL, 
	cues_json JSON NOT NULL, 
	evidence_json JSON NOT NULL, 
	operation_json JSON NOT NULL, 
	reviewed BOOLEAN NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_media_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(parent_revision_id) REFERENCES media_edit_plan_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(editorial_transcript_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_media_edit_plan_revision UNIQUE (plan_id, revision_number), 
	FOREIGN KEY(plan_id) REFERENCES media_edit_plans (id) ON DELETE CASCADE, 
	FOREIGN KEY(timing_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE media_edit_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	active_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE outcome_plan_history (
	id INTEGER NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE outcome_plans (
	session_id VARCHAR(36) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE output_assemblies (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	generation_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	settings_hash VARCHAR(128), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE owner_account (
	singleton_id INTEGER NOT NULL, 
	password_hash TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (singleton_id)
);
CREATE TABLE password_reset_grants (
	id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	created_by_user_id VARCHAR(36) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	auth_revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	consumed_at DATETIME, 
	revoked_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_password_reset_grants_auth_revision CHECK (auth_revision >= 1), 
	CONSTRAINT fk_password_reset_grants_created_by_user_id_users FOREIGN KEY(created_by_user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_password_reset_grants_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_password_reset_grants_token_hash UNIQUE (token_hash)
);
CREATE TABLE performance_batches (
	id VARCHAR(36) NOT NULL, 
	performance_plan_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	segment_ids_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	lease_token VARCHAR(64), 
	lease_expires_at DATETIME, 
	annotations_json JSON NOT NULL, 
	response_hash VARCHAR(128), 
	usage_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_performance_batch_ordinal UNIQUE (performance_plan_id, ordinal), 
	FOREIGN KEY(performance_plan_id) REFERENCES performance_plans (id) ON DELETE CASCADE
);
CREATE TABLE performance_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	plan_revision_id VARCHAR(36) NOT NULL, 
	base_signature VARCHAR(128) NOT NULL, 
	settings_json JSON NOT NULL, 
	units_json JSON NOT NULL, 
	manual_annotations_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	version INTEGER NOT NULL, 
	job_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	adopted_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE "project_folder_memberships" (
	folder_id VARCHAR(36) NOT NULL, 
	project_session_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	position INTEGER NOT NULL, 
	PRIMARY KEY (folder_id, project_session_id), 
	CONSTRAINT fk_project_folder_memberships_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE, 
	CONSTRAINT uq_project_folder_memberships_folder_project UNIQUE (folder_id, project_id), 
	CONSTRAINT ck_project_folder_membership_position CHECK (position >= 0), 
	FOREIGN KEY(folder_id) REFERENCES project_folders (id) ON DELETE CASCADE, 
	FOREIGN KEY(project_session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE "project_folders" (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(128) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	parent_id VARCHAR(36), 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_project_folders_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(parent_id) REFERENCES project_folders (id) ON DELETE RESTRICT
);
CREATE TABLE project_memberships (
	project_id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	granted_by_user_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (project_id, user_id), 
	FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE, 
	FOREIGN KEY(granted_by_user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT ck_project_memberships_role CHECK (role IN ('manager', 'editor', 'reviewer', 'viewer')), 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE TABLE project_sound_cues (
	id VARCHAR(36) NOT NULL, 
	logical_id VARCHAR(36) NOT NULL, 
	plan_id VARCHAR(36) NOT NULL, 
	variant_id VARCHAR(36) NOT NULL, 
	anchor_json JSON NOT NULL, 
	playback_json JSON NOT NULL, 
	included BOOLEAN NOT NULL, 
	placement_status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_project_sound_cue_logical UNIQUE (plan_id, logical_id), 
	CONSTRAINT ck_project_sound_cue_placement CHECK (placement_status IN ('ready', 'needs_placement')), 
	FOREIGN KEY(plan_id) REFERENCES project_sound_plans (id) ON DELETE CASCADE, 
	FOREIGN KEY(variant_id) REFERENCES sound_variants (id) ON DELETE RESTRICT
);
CREATE TABLE project_sound_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	revision INTEGER NOT NULL, 
	speech_plan_revision_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_project_sound_plan_revision UNIQUE (session_id, revision), 
	CONSTRAINT ck_project_sound_plan_revision_positive CHECK (revision >= 1), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(speech_plan_revision_id) REFERENCES generation_plan_revisions (id) ON DELETE SET NULL
);
CREATE TABLE projects (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	source_session_id VARCHAR(36), 
	name VARCHAR(255) NOT NULL, 
	created_by_user_id VARCHAR(36), 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_projects_revision CHECK (revision >= 1), 
	CONSTRAINT uq_projects_source_session_id UNIQUE (source_session_id), 
	FOREIGN KEY(created_by_user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_session_id) REFERENCES sessions (id) ON DELETE SET NULL, 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE "pronunciation_entries" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	scope VARCHAR(16) NOT NULL, 
	session_id VARCHAR(36), 
	source_form TEXT NOT NULL, 
	normalized_form VARCHAR(512) NOT NULL, 
	language VARCHAR(40) NOT NULL, 
	phonetic TEXT NOT NULL, 
	alphabet VARCHAR(32) NOT NULL, 
	backend VARCHAR(80) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	source VARCHAR(40) NOT NULL, 
	notes TEXT, 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_pronunciation_entry_identity UNIQUE (scope, session_id, normalized_form, language, backend), 
	CONSTRAINT fk_pronunciation_entries_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_pronunciation_entries_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE "provider_models" (
	id VARCHAR(36) NOT NULL, 
	provider_id VARCHAR(36) NOT NULL, 
	model_id VARCHAR(255) NOT NULL, 
	is_active BOOLEAN DEFAULT 0 NOT NULL, 
	is_default BOOLEAN NOT NULL, 
	default_temperature FLOAT, 
	default_reasoning_effort VARCHAR(80), 
	input_cost_per_million FLOAT, 
	cached_input_cost_per_million FLOAT, 
	output_cost_per_million FLOAT, 
	context_window_tokens INTEGER NOT NULL, 
	max_output_tokens INTEGER, 
	input_modalities_json JSON NOT NULL, 
	output_modalities_json JSON NOT NULL, 
	options_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_provider_model UNIQUE (provider_id, model_id), 
	FOREIGN KEY(provider_id) REFERENCES providers (id) ON DELETE CASCADE
);
CREATE TABLE "providers" (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	provider_key VARCHAR(80) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	base_url TEXT, 
	secret_ref VARCHAR(255), 
	options_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_providers_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_provider_workspace_identity UNIQUE (workspace_id, kind, provider_key, label)
);
CREATE TABLE quick_transcription_owners (
	transcription_id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	PRIMARY KEY (transcription_id), 
	CONSTRAINT fk_quick_transcription_owners_transcription_id FOREIGN KEY(transcription_id) REFERENCES quick_transcriptions (id) ON DELETE CASCADE, 
	CONSTRAINT fk_quick_transcription_owners_user_id FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_quick_transcription_owners_workspace_id FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE quick_transcriptions (
	id VARCHAR(36) NOT NULL, 
	owner_subject VARCHAR(255) NOT NULL, 
	job_id VARCHAR(36), 
	source_suffix VARCHAR(16) NOT NULL, 
	size_bytes INTEGER NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	uploaded_bytes INTEGER NOT NULL, 
	next_chunk_index INTEGER NOT NULL, 
	format VARCHAR(8) NOT NULL, 
	settings_json JSON NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (job_id), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE "research_cache_entries" (
	cache_key VARCHAR(64) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	provider VARCHAR(40) NOT NULL, 
	operation VARCHAR(40) NOT NULL, 
	request_json JSON NOT NULL, 
	response_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (cache_key), 
	CONSTRAINT fk_research_cache_entries_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE, 
	CONSTRAINT fk_research_cache_entries_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE resource_claims (
	resource_key VARCHAR(160) NOT NULL, 
	job_id VARCHAR(36) NOT NULL, 
	lease_owner VARCHAR(120) NOT NULL, 
	lease_generation INTEGER NOT NULL, 
	expires_at DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (resource_key), 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE CASCADE
);
CREATE TABLE segment_lineage (
	parent_segment_id VARCHAR(36) NOT NULL, 
	child_segment_id VARCHAR(36) NOT NULL, 
	relation VARCHAR(40) NOT NULL, 
	sequence INTEGER NOT NULL, 
	PRIMARY KEY (parent_segment_id, child_segment_id), 
	FOREIGN KEY(child_segment_id) REFERENCES segments (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_segment_id) REFERENCES segments (id) ON DELETE CASCADE
);
CREATE TABLE segments (
	id VARCHAR(36) NOT NULL, 
	revision_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	node_kind VARCHAR(40) NOT NULL, 
	start_ms INTEGER, 
	end_ms INTEGER, 
	text TEXT NOT NULL, 
	speaker VARCHAR(160), 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(revision_id) REFERENCES document_revisions (id) ON DELETE CASCADE, 
	CONSTRAINT uq_revision_segment_ordinal UNIQUE (revision_id, ordinal)
);
CREATE TABLE session_purges (
	session_id VARCHAR(36) NOT NULL, 
	state VARCHAR(24) NOT NULL, 
	manifest_json JSON NOT NULL, 
	expected_revision INTEGER NOT NULL, 
	impact_token VARCHAR(64) NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id)
);
CREATE TABLE session_settings (
	session_id VARCHAR(36) NOT NULL, 
	section VARCHAR(80) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id, section), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE session_settings_history (
	id INTEGER NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	section VARCHAR(80) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE session_sources (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_asset_id VARCHAR(36) NOT NULL, 
	role VARCHAR(80) NOT NULL, 
	is_current BOOLEAN NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_asset_id) REFERENCES source_assets (id) ON DELETE RESTRICT, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	CONSTRAINT uq_session_source_attachment UNIQUE (session_id, source_asset_id, role)
);
CREATE TABLE session_stage_selections (
	session_id VARCHAR(36) NOT NULL, 
	stage_key VARCHAR(80) NOT NULL, 
	artifact_id VARCHAR(36), 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (session_id, stage_key), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE "sessions" (
	id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	storage_key VARCHAR(36) NOT NULL, 
	legacy_name VARCHAR(255), 
	legacy_path TEXT, 
	workflow_kind VARCHAR(32) NOT NULL, 
	interface_mode VARCHAR(16) DEFAULT 'advanced' NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	target_language VARCHAR(40), 
	workflow_preset VARCHAR(64) NOT NULL, 
	included_stages_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	trashed_at DATETIME, 
	purge_after DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_sessions_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE RESTRICT, 
	UNIQUE (storage_key)
);
CREATE TABLE "sound_items" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	tags_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	archived BOOLEAN NOT NULL, 
	preferred_variant_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_sound_items_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(preferred_variant_id) REFERENCES sound_variants (id) ON DELETE RESTRICT
);
CREATE TABLE "sound_variants" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	item_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	state VARCHAR(16) NOT NULL, 
	fingerprint VARCHAR(64), 
	provenance_json JSON NOT NULL, 
	sample_rate INTEGER, 
	channels INTEGER, 
	frame_count INTEGER, 
	duration_seconds FLOAT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_sound_variants_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE RESTRICT, 
	FOREIGN KEY(item_id) REFERENCES sound_items (id) ON DELETE RESTRICT
);
CREATE TABLE "source_assets" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	artifact_id VARCHAR(36), 
	display_name VARCHAR(255) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	mime_type VARCHAR(160), 
	external_path TEXT, 
	size_bytes INTEGER, 
	content_hash VARCHAR(128), 
	state VARCHAR(32) NOT NULL, 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_source_assets_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE source_cleaning_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	phase VARCHAR(80) NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_source_cleaning_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES source_cleaning_dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE source_cleaning_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	job_id VARCHAR(36), 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_format VARCHAR(16) NOT NULL, 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	baseline_artifact_id VARCHAR(36), 
	index_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	accepted_operation_count INTEGER NOT NULL, 
	rejected_proposal_count INTEGER NOT NULL, 
	validation_json JSON NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(index_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(baseline_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL
);
CREATE TABLE sources (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	display_name VARCHAR(255) NOT NULL, 
	artifact_id VARCHAR(36), 
	external_path TEXT, 
	content_hash VARCHAR(128), 
	metadata_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE speech_optimization_dispatch_batches (
	id VARCHAR(36) NOT NULL, 
	dispatch_run_id VARCHAR(36) NOT NULL, 
	ordinal INTEGER NOT NULL, 
	input_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	lease_token VARCHAR(160), 
	claim_key VARCHAR(200), 
	lease_expires_at DATETIME, 
	normalized_output_json JSON, 
	output_hash VARCHAR(64), 
	submission_key VARCHAR(200), 
	accepted_at DATETIME, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_speech_optimization_dispatch_batch_ordinal UNIQUE (dispatch_run_id, ordinal), 
	FOREIGN KEY(dispatch_run_id) REFERENCES speech_optimization_dispatch_runs (id) ON DELETE CASCADE
);
CREATE TABLE speech_optimization_dispatch_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_state VARCHAR(24) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_format VARCHAR(16) NOT NULL, 
	language VARCHAR(40) NOT NULL, 
	voice_language VARCHAR(40), 
	tts_service VARCHAR(80), 
	settings_json JSON NOT NULL, 
	selection_snapshot_json JSON NOT NULL, 
	input_hash VARCHAR(64) NOT NULL, 
	output_head_artifact_id VARCHAR(36), 
	result_artifact_id VARCHAR(36), 
	result_revision_id VARCHAR(36), 
	status VARCHAR(24) NOT NULL, 
	batch_count INTEGER NOT NULL, 
	completed_batch_count INTEGER NOT NULL, 
	error_code VARCHAR(120), 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(output_head_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(result_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(result_revision_id) REFERENCES document_revisions (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
CREATE TABLE speech_plan_reviews (
	revision_id VARCHAR(36) NOT NULL, 
	content_hash VARCHAR(128) NOT NULL, 
	reviewed_at DATETIME NOT NULL, 
	PRIMARY KEY (revision_id), 
	FOREIGN KEY(revision_id) REFERENCES generation_plan_revisions (id) ON DELETE CASCADE
);
CREATE TABLE stage_runs (
	id VARCHAR(36) NOT NULL, 
	workflow_run_id VARCHAR(36) NOT NULL, 
	stage_key VARCHAR(80) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_hash VARCHAR(128), 
	artifact_id VARCHAR(36), 
	detail TEXT, 
	started_at DATETIME, 
	finished_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE CASCADE, 
	CONSTRAINT uq_workflow_stage UNIQUE (workflow_run_id, stage_key)
);
CREATE TABLE "stored_credentials" (
	"key" VARCHAR(255) NOT NULL, 
	label VARCHAR(160) NOT NULL, 
	secret_value TEXT NOT NULL, 
	created_at DATETIME DEFAULT (CURRENT_TIMESTAMP) NOT NULL, 
	updated_at DATETIME DEFAULT (CURRENT_TIMESTAMP) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	revision INTEGER DEFAULT 1 NOT NULL, 
	CONSTRAINT pk_stored_credentials PRIMARY KEY (workspace_id, "key"), 
	CONSTRAINT fk_stored_credentials_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE subtitle_evidence (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	source_artifact_id VARCHAR(36) NOT NULL, 
	source_media_artifact_id VARCHAR(36), 
	source_revision_id VARCHAR(36) NOT NULL, 
	source_segment_id VARCHAR(36), 
	cue_id INTEGER NOT NULL, 
	start_ms INTEGER NOT NULL, 
	end_ms INTEGER NOT NULL, 
	clip_start_ms INTEGER NOT NULL, 
	clip_end_ms INTEGER NOT NULL, 
	reason TEXT NOT NULL, 
	routes_json JSON NOT NULL, 
	audio_model_ids_json JSON NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	job_id VARCHAR(36), 
	clip_artifact_id VARCHAR(36), 
	candidates_json JSON NOT NULL, 
	resolution_json JSON NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_media_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(clip_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_revision_id) REFERENCES document_revisions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(source_segment_id) REFERENCES segments (id) ON DELETE SET NULL
);
CREATE TABLE timed_words (
	id VARCHAR(36) NOT NULL, 
	revision_id VARCHAR(36) NOT NULL, 
	segment_id VARCHAR(36), 
	ordinal INTEGER NOT NULL, 
	text TEXT NOT NULL, 
	start_ms INTEGER NOT NULL, 
	end_ms INTEGER NOT NULL, 
	speaker VARCHAR(160), 
	confidence FLOAT, 
	metadata_json JSON NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(segment_id) REFERENCES segments (id) ON DELETE SET NULL, 
	FOREIGN KEY(revision_id) REFERENCES document_revisions (id) ON DELETE CASCADE, 
	CONSTRAINT uq_timed_word_ordinal UNIQUE (revision_id, ordinal)
);
CREATE TABLE "training_runs" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	kind VARCHAR(48) NOT NULL, 
	voice_id VARCHAR(36), 
	job_id VARCHAR(36), 
	source_artifact_id VARCHAR(36), 
	source_text_artifact_id VARCHAR(36), 
	output_artifact_id VARCHAR(36), 
	model_name VARCHAR(255) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	error_message TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_training_runs_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	UNIQUE (job_id), 
	FOREIGN KEY(output_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_text_artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE SET NULL
);
CREATE TABLE translation_project_branches (
	id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	target_language VARCHAR(40) NOT NULL, 
	source_checkpoint_artifact_id VARCHAR(36) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (session_id), 
	FOREIGN KEY(source_checkpoint_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(project_id) REFERENCES translation_projects (id) ON DELETE CASCADE, 
	CONSTRAINT uq_translation_project_language UNIQUE (project_id, target_language), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE translation_project_operations (
	id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(255) NOT NULL, 
	target_instance_id VARCHAR(255) NOT NULL, 
	action VARCHAR(24) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	preview_digest VARCHAR(64) NOT NULL, 
	preview_json JSON NOT NULL, 
	children_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	cancel_requested BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(project_id) REFERENCES translation_projects (id) ON DELETE CASCADE
);
CREATE TABLE "translation_projects" (
	id VARCHAR(36) NOT NULL, 
	project_root_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	source_session_id VARCHAR(36) NOT NULL, 
	checkpoint_artifact_id VARCHAR(36) NOT NULL, 
	source_content_hash VARCHAR(128) NOT NULL, 
	source_language VARCHAR(40) NOT NULL, 
	source_media_edit_revision_id VARCHAR(36), 
	source_media_edit_content_hash VARCHAR(128), 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_translation_projects_project_root_id_projects FOREIGN KEY(project_root_id) REFERENCES projects (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_translation_projects_project_root_id UNIQUE (project_root_id), 
	UNIQUE (source_session_id), 
	FOREIGN KEY(source_session_id) REFERENCES sessions (id) ON DELETE RESTRICT, 
	FOREIGN KEY(checkpoint_artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT
);
CREATE TABLE "upload_sessions" (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36), 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	filename VARCHAR(255) NOT NULL, 
	mime_type VARCHAR(160), 
	size_bytes INTEGER NOT NULL, 
	chunk_size INTEGER NOT NULL, 
	chunk_count INTEGER NOT NULL, 
	received_json JSON NOT NULL, 
	expected_hash VARCHAR(128), 
	temporary_relative_path TEXT NOT NULL, 
	state VARCHAR(32) NOT NULL, 
	result_json JSON, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_upload_sessions_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_upload_sessions_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE RESTRICT, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE "usage_events" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	project_id VARCHAR(36), 
	session_id VARCHAR(36), 
	workflow_run_id VARCHAR(36), 
	job_id VARCHAR(36), 
	artifact_id VARCHAR(36), 
	generation_run_id VARCHAR(36), 
	agent_run_id VARCHAR(36), 
	request_key VARCHAR(200), 
	stage VARCHAR(80), 
	provider_key VARCHAR(80) NOT NULL, 
	model_id VARCHAR(255) NOT NULL, 
	input_tokens INTEGER NOT NULL, 
	cached_input_tokens INTEGER NOT NULL, 
	output_tokens INTEGER NOT NULL, 
	cost_usd FLOAT, 
	cost_source VARCHAR(40), 
	raw_usage_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_usage_events_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_usage_events_project_id_projects FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_usage_event_agent_request UNIQUE (agent_run_id, request_key), 
	FOREIGN KEY(generation_run_id) REFERENCES generation_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(agent_run_id) REFERENCES agent_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(workflow_run_id) REFERENCES workflow_runs (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE SET NULL, 
	FOREIGN KEY(job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE SET NULL
);
CREATE TABLE user_credentials (
	user_id VARCHAR(36) NOT NULL, 
	login_name VARCHAR(64) NOT NULL, 
	password_hash TEXT, 
	auth_revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (user_id), 
	CONSTRAINT ck_user_credentials_auth_revision CHECK (auth_revision >= 1), 
	CONSTRAINT fk_user_credentials_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_user_credentials_login_name UNIQUE (login_name)
);
INSERT INTO "user_credentials" VALUES('ffa56d99-c17f-4201-a1a2-10347e8a758a','owner',NULL,1,'2026-10-25 03:43:12','2026-10-25 03:43:12');
CREATE TABLE users (
	id VARCHAR(36) NOT NULL, 
	legacy_subject VARCHAR(255), 
	display_name VARCHAR(255) NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	is_instance_admin BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_users_legacy_subject UNIQUE (legacy_subject)
);
INSERT INTO "users" VALUES('ffa56d99-c17f-4201-a1a2-10347e8a758a','owner','Owner',1,1,'2026-10-25 03:43:12','2026-10-25 03:43:12');
CREATE TABLE voice_catalog_overrides (
	workspace_id VARCHAR(36) NOT NULL, 
	voice_key VARCHAR(1024) NOT NULL, 
	voice_ref_json JSON NOT NULL, 
	name VARCHAR(255), 
	description TEXT, 
	voice_category VARCHAR(20), 
	profile_json JSON, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (workspace_id, voice_key), 
	CONSTRAINT fk_voice_catalog_overrides_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE "voice_collection_members" (
	workspace_id VARCHAR(36) NOT NULL, 
	collection_id VARCHAR(36) NOT NULL, 
	voice_key VARCHAR(1024) NOT NULL, 
	voice_ref_json JSON NOT NULL, 
	managed_voice_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (collection_id, voice_key), 
	CONSTRAINT fk_voice_collection_members_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(collection_id) REFERENCES voice_collections (id) ON DELETE CASCADE, 
	FOREIGN KEY(managed_voice_id) REFERENCES voices (id) ON DELETE CASCADE
);
CREATE TABLE "voice_collections" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	description TEXT, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_voice_collections_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_voice_collections_workspace_name UNIQUE (workspace_id, name)
);
CREATE TABLE "voice_samples" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	voice_id VARCHAR(36) NOT NULL, 
	artifact_id VARCHAR(36) NOT NULL, 
	transcript TEXT, 
	transcript_language VARCHAR(40), 
	transcript_reviewed BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_voice_samples_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	FOREIGN KEY(artifact_id) REFERENCES artifacts (id) ON DELETE RESTRICT, 
	FOREIGN KEY(voice_id) REFERENCES voices (id) ON DELETE CASCADE
);
CREATE TABLE "voices" (
	id VARCHAR(36) NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	language VARCHAR(40), 
	description TEXT, 
	rvc_model_ref VARCHAR(255), 
	metadata_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_voices_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT, 
	CONSTRAINT uq_voices_workspace_name UNIQUE (workspace_id, name)
);
CREATE TABLE workflow_execution_plans (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	principal_subject VARCHAR(200) NOT NULL, 
	target_instance_id VARCHAR(36) NOT NULL, 
	plan_digest VARCHAR(64) NOT NULL, 
	plan_json JSON NOT NULL, 
	state_fingerprint VARCHAR(64) NOT NULL, 
	required_confirmations_json JSON NOT NULL, 
	resulting_job_id VARCHAR(36), 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	consumed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(resulting_job_id) REFERENCES jobs (id) ON DELETE SET NULL, 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE workflow_runs (
	id VARCHAR(36) NOT NULL, 
	session_id VARCHAR(36) NOT NULL, 
	preset VARCHAR(64) NOT NULL, 
	status VARCHAR(32) NOT NULL, 
	settings_json JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id) ON DELETE CASCADE
);
CREATE TABLE workspace_memberships (
	workspace_id VARCHAR(36) NOT NULL, 
	user_id VARCHAR(36) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (workspace_id, user_id), 
	CONSTRAINT ck_workspace_memberships_role CHECK (role IN ('owner', 'admin', 'member')), 
	FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE RESTRICT
);
INSERT INTO "workspace_memberships" VALUES('dec8a94f-8e0c-4676-b184-2d45a987e41f','ffa56d99-c17f-4201-a1a2-10347e8a758a','owner','2026-10-25 03:43:12');
CREATE TABLE workspace_settings (
	workspace_id VARCHAR(36) NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (workspace_id, "key"), 
	CONSTRAINT fk_workspace_settings_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE workspace_settings_history (
	id INTEGER NOT NULL, 
	workspace_id VARCHAR(36) NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	value_json JSON NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT fk_workspace_settings_history_workspace_id_workspaces FOREIGN KEY(workspace_id) REFERENCES workspaces (id) ON DELETE RESTRICT
);
CREATE TABLE workspaces (
	id VARCHAR(36) NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	personal_owner_user_id VARCHAR(36), 
	state VARCHAR(16) NOT NULL, 
	revision INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_workspaces_revision CHECK (revision >= 1), 
	CONSTRAINT ck_workspaces_personal_owner CHECK ((kind = 'personal' AND personal_owner_user_id IS NOT NULL) OR (kind = 'team' AND personal_owner_user_id IS NULL)), 
	CONSTRAINT ck_workspaces_state CHECK (state IN ('active', 'archived')), 
	CONSTRAINT ck_workspaces_kind CHECK (kind IN ('personal', 'team')), 
	CONSTRAINT uq_workspaces_personal_owner_user_id UNIQUE (personal_owner_user_id), 
	FOREIGN KEY(personal_owner_user_id) REFERENCES users (id) ON DELETE RESTRICT
);
INSERT INTO "workspaces" VALUES('dec8a94f-8e0c-4676-b184-2d45a987e41f','personal','Personal','ffa56d99-c17f-4201-a1a2-10347e8a758a','active',1,'2026-10-25 03:43:12','2026-10-25 03:43:12');
CREATE INDEX ix_projects_workspace_id ON projects (workspace_id);
CREATE INDEX ix_app_settings_history_key ON app_settings_history ("key");
CREATE INDEX ix_audit_events_principal_subject ON audit_events (principal_subject);
CREATE INDEX ix_audit_events_created_at ON audit_events (created_at);
CREATE INDEX ix_audit_events_plan_id ON audit_events (plan_id);
CREATE INDEX ix_audit_events_idempotency_key ON audit_events (idempotency_key);
CREATE INDEX ix_audit_events_action ON audit_events (action);
CREATE INDEX ix_audit_events_resource_id ON audit_events (resource_id);
CREATE INDEX ix_audit_events_outcome ON audit_events (outcome);
CREATE INDEX ix_audit_events_request_id ON audit_events (request_id);
CREATE INDEX ix_api_idempotency_expires_at ON api_idempotency (expires_at);
CREATE INDEX ix_api_idempotency_resource_id ON api_idempotency (resource_id);
CREATE INDEX ix_capability_snapshots_created_at ON capability_snapshots (created_at);
CREATE INDEX ix_session_settings_history_session_id ON session_settings_history (session_id);
CREATE INDEX ix_outcome_plan_history_session_id ON outcome_plan_history (session_id);
CREATE INDEX ix_documents_session_id ON documents (session_id);
CREATE UNIQUE INDEX ix_generation_plans_session_id ON generation_plans (session_id);
CREATE UNIQUE INDEX ix_media_edit_plans_session_id ON media_edit_plans (session_id);
CREATE INDEX ix_knowledge_ledgers_session_id ON knowledge_ledgers (session_id);
CREATE INDEX ix_automation_clients_user_id ON automation_clients (user_id);
CREATE INDEX ix_automation_clients_revoked_at ON automation_clients (revoked_at);
CREATE INDEX ix_workspace_settings_history_workspace_key ON workspace_settings_history (workspace_id, "key");
CREATE INDEX ix_document_revisions_document_id ON document_revisions (document_id);
CREATE INDEX ix_automation_enrollment_grants_client_id ON automation_enrollment_grants (client_id);
CREATE INDEX ix_automation_enrollment_grants_code_prefix ON automation_enrollment_grants (code_prefix);
CREATE INDEX ix_automation_enrollment_grants_expires_at ON automation_enrollment_grants (expires_at);
CREATE INDEX ix_api_tokens_client_id ON api_tokens (client_id);
CREATE INDEX ix_api_tokens_token_prefix ON api_tokens (token_prefix);
CREATE INDEX ix_api_tokens_user_id ON api_tokens (user_id);
CREATE INDEX ix_api_tokens_expires_at ON api_tokens (expires_at);
CREATE INDEX ix_api_tokens_subject ON api_tokens (subject);
CREATE INDEX ix_quick_transcriptions_owner_subject ON quick_transcriptions (owner_subject);
CREATE INDEX ix_quick_transcriptions_expires_at ON quick_transcriptions (expires_at);
CREATE INDEX ix_job_events_created_at ON job_events (created_at);
CREATE INDEX ix_job_events_job_id ON job_events (job_id);
CREATE INDEX ix_job_events_event_type ON job_events (event_type);
CREATE INDEX idx_artifact_edges_child_parent ON artifact_edges (child_artifact_id, parent_artifact_id);
CREATE INDEX ix_session_stage_selections_artifact_id ON session_stage_selections (artifact_id);
CREATE INDEX ix_segments_revision_id ON segments (revision_id);
CREATE INDEX idx_segments_revision_timing ON segments (revision_id, start_ms, end_ms);
CREATE INDEX ix_generation_plan_revisions_source_revision_id ON generation_plan_revisions (source_revision_id);
CREATE INDEX ix_generation_plan_revisions_parent_revision_id ON generation_plan_revisions (parent_revision_id);
CREATE INDEX ix_generation_plan_revisions_plan_id ON generation_plan_revisions (plan_id);
CREATE INDEX ix_media_edit_plan_revisions_plan_id ON media_edit_plan_revisions (plan_id);
CREATE INDEX ix_media_edit_plan_revisions_editorial_transcript_artifact_id ON media_edit_plan_revisions (editorial_transcript_artifact_id);
CREATE INDEX ix_media_edit_plan_revisions_timing_artifact_id ON media_edit_plan_revisions (timing_artifact_id);
CREATE INDEX ix_media_edit_plan_revisions_source_media_artifact_id ON media_edit_plan_revisions (source_media_artifact_id);
CREATE INDEX ix_media_edit_plan_revisions_parent_revision_id ON media_edit_plan_revisions (parent_revision_id);
CREATE INDEX ix_resource_claims_lease_owner ON resource_claims (lease_owner);
CREATE INDEX ix_resource_claims_expires_at ON resource_claims (expires_at);
CREATE INDEX ix_resource_claims_job_id ON resource_claims (job_id);
CREATE INDEX ix_agent_runs_source_content_hash ON agent_runs (source_content_hash);
CREATE INDEX ix_agent_runs_settings_hash ON agent_runs (settings_hash);
CREATE INDEX ix_agent_runs_session_id ON agent_runs (session_id);
CREATE INDEX ix_agent_runs_kind ON agent_runs (kind);
CREATE INDEX ix_agent_runs_status ON agent_runs (status);
CREATE INDEX ix_dispatch_runs_output_head_artifact_id ON dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_dispatch_runs_kind ON dispatch_runs (kind);
CREATE INDEX ix_dispatch_runs_source_artifact_id ON dispatch_runs (source_artifact_id);
CREATE INDEX ix_dispatch_runs_source_revision_id ON dispatch_runs (source_revision_id);
CREATE INDEX ix_dispatch_runs_result_artifact_id ON dispatch_runs (result_artifact_id);
CREATE INDEX ix_dispatch_runs_status ON dispatch_runs (status);
CREATE INDEX ix_dispatch_runs_created_at ON dispatch_runs (created_at);
CREATE INDEX ix_dispatch_runs_updated_at ON dispatch_runs (updated_at);
CREATE INDEX ix_dispatch_runs_result_revision_id ON dispatch_runs (result_revision_id);
CREATE INDEX ix_dispatch_runs_session_id ON dispatch_runs (session_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_session_id ON source_cleaning_dispatch_runs (session_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_created_at ON source_cleaning_dispatch_runs (created_at);
CREATE INDEX ix_source_cleaning_dispatch_runs_updated_at ON source_cleaning_dispatch_runs (updated_at);
CREATE INDEX ix_source_cleaning_dispatch_runs_baseline_artifact_id ON source_cleaning_dispatch_runs (baseline_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_output_head_artifact_id ON source_cleaning_dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_job_id ON source_cleaning_dispatch_runs (job_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_status ON source_cleaning_dispatch_runs (status);
CREATE INDEX ix_source_cleaning_dispatch_runs_index_artifact_id ON source_cleaning_dispatch_runs (index_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_result_artifact_id ON source_cleaning_dispatch_runs (result_artifact_id);
CREATE INDEX ix_source_cleaning_dispatch_runs_source_artifact_id ON source_cleaning_dispatch_runs (source_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_result_artifact_id ON speech_optimization_dispatch_runs (result_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_created_at ON speech_optimization_dispatch_runs (created_at);
CREATE INDEX ix_speech_optimization_dispatch_runs_updated_at ON speech_optimization_dispatch_runs (updated_at);
CREATE INDEX ix_speech_optimization_dispatch_runs_source_artifact_id ON speech_optimization_dispatch_runs (source_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_output_head_artifact_id ON speech_optimization_dispatch_runs (output_head_artifact_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_result_revision_id ON speech_optimization_dispatch_runs (result_revision_id);
CREATE INDEX ix_speech_optimization_dispatch_runs_status ON speech_optimization_dispatch_runs (status);
CREATE INDEX ix_speech_optimization_dispatch_runs_session_id ON speech_optimization_dispatch_runs (session_id);
CREATE INDEX ix_exports_session_id ON exports (session_id);
CREATE INDEX ix_workflow_execution_plans_session_id ON workflow_execution_plans (session_id);
CREATE INDEX ix_workflow_execution_plans_resulting_job_id ON workflow_execution_plans (resulting_job_id);
CREATE INDEX ix_workflow_execution_plans_expires_at ON workflow_execution_plans (expires_at);
CREATE INDEX ix_workflow_execution_plans_consumed_at ON workflow_execution_plans (consumed_at);
CREATE INDEX ix_workflow_execution_plans_principal_subject ON workflow_execution_plans (principal_subject);
CREATE INDEX ix_workflow_execution_plans_plan_digest ON workflow_execution_plans (plan_digest);
CREATE INDEX ix_translation_project_branches_project_id ON translation_project_branches (project_id);
CREATE INDEX ix_translation_project_operations_project_id ON translation_project_operations (project_id);
CREATE INDEX idx_session_sources_current_updated ON session_sources (session_id, is_current DESC, updated_at DESC, id);
CREATE INDEX ix_session_sources_source_asset_id ON session_sources (source_asset_id);
CREATE INDEX ix_session_sources_session_id ON session_sources (session_id);
CREATE INDEX ix_subtitle_evidence_source_segment_id ON subtitle_evidence (source_segment_id);
CREATE INDEX ix_subtitle_evidence_clip_artifact_id ON subtitle_evidence (clip_artifact_id);
CREATE INDEX ix_subtitle_evidence_source_artifact_id ON subtitle_evidence (source_artifact_id);
CREATE INDEX ix_subtitle_evidence_source_media_artifact_id ON subtitle_evidence (source_media_artifact_id);
CREATE INDEX ix_subtitle_evidence_status ON subtitle_evidence (status);
CREATE UNIQUE INDEX ix_subtitle_evidence_job_id ON subtitle_evidence (job_id);
CREATE INDEX ix_subtitle_evidence_session_id ON subtitle_evidence (session_id);
CREATE INDEX ix_subtitle_evidence_source_revision_id ON subtitle_evidence (source_revision_id);
CREATE INDEX ix_segment_lineage_child_segment_id ON segment_lineage (child_segment_id);
CREATE INDEX ix_timed_words_segment_id ON timed_words (segment_id);
CREATE INDEX ix_timed_words_revision_id ON timed_words (revision_id);
CREATE INDEX ix_generation_runs_status ON generation_runs (status);
CREATE INDEX ix_generation_runs_output_generation_run_id ON generation_runs (output_generation_run_id);
CREATE INDEX ix_generation_runs_job_id ON generation_runs (job_id);
CREATE INDEX ix_generation_runs_plan_revision_id ON generation_runs (plan_revision_id);
CREATE INDEX ix_generation_runs_source_generation_run_id ON generation_runs (source_generation_run_id);
CREATE INDEX ix_generation_runs_session_id ON generation_runs (session_id);
CREATE INDEX ix_performance_plans_status ON performance_plans (status);
CREATE INDEX ix_performance_plans_session_id ON performance_plans (session_id);
CREATE INDEX ix_performance_plans_plan_revision_id ON performance_plans (plan_revision_id);
CREATE INDEX ix_generation_segments_voice_id ON generation_segments (voice_id);
CREATE INDEX ix_generation_segments_status ON generation_segments (status);
CREATE INDEX ix_generation_segments_plan_revision_id ON generation_segments (plan_revision_id);
CREATE INDEX ix_generation_segments_revision_removed_status ON generation_segments (plan_revision_id, removed, status);
CREATE INDEX ix_generation_segments_alignment_group ON generation_segments (alignment_group);
CREATE INDEX ix_generation_segments_marked ON generation_segments (marked);
CREATE INDEX ix_generation_segments_optimization_status ON generation_segments (optimization_status);
CREATE INDEX ix_dispatch_batches_lease_expires_at ON dispatch_batches (lease_expires_at);
CREATE INDEX ix_dispatch_batches_dispatch_run_id ON dispatch_batches (dispatch_run_id);
CREATE INDEX ix_dispatch_batches_status ON dispatch_batches (status);
CREATE INDEX ix_source_cleaning_dispatch_batches_lease_expires_at ON source_cleaning_dispatch_batches (lease_expires_at);
CREATE INDEX ix_source_cleaning_dispatch_batches_status ON source_cleaning_dispatch_batches (status);
CREATE INDEX ix_source_cleaning_dispatch_batches_phase ON source_cleaning_dispatch_batches (phase);
CREATE INDEX ix_source_cleaning_dispatch_batches_dispatch_run_id ON source_cleaning_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_speech_optimization_dispatch_batches_dispatch_run_id ON speech_optimization_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_speech_optimization_dispatch_batches_lease_expires_at ON speech_optimization_dispatch_batches (lease_expires_at);
CREATE INDEX ix_speech_optimization_dispatch_batches_status ON speech_optimization_dispatch_batches (status);
CREATE INDEX ix_media_edit_dispatch_runs_status ON media_edit_dispatch_runs (status);
CREATE INDEX ix_media_edit_dispatch_runs_source_revision_id ON media_edit_dispatch_runs (source_revision_id);
CREATE INDEX ix_media_edit_dispatch_runs_result_revision_id ON media_edit_dispatch_runs (result_revision_id);
CREATE INDEX ix_media_edit_dispatch_runs_updated_at ON media_edit_dispatch_runs (updated_at);
CREATE INDEX ix_media_edit_dispatch_runs_created_at ON media_edit_dispatch_runs (created_at);
CREATE INDEX ix_media_edit_dispatch_runs_session_id ON media_edit_dispatch_runs (session_id);
CREATE INDEX ix_agent_steps_agent_run_id ON agent_steps (agent_run_id);
CREATE INDEX ix_performance_batches_status ON performance_batches (status);
CREATE INDEX ix_performance_batches_performance_plan_id ON performance_batches (performance_plan_id);
CREATE INDEX ix_generation_segment_revisions_generation_segment_id ON generation_segment_revisions (generation_segment_id);
CREATE INDEX ix_audio_takes_status ON audio_takes (status);
CREATE INDEX ix_audio_takes_generation_segment_id ON audio_takes (generation_segment_id);
CREATE INDEX ix_audio_takes_parent_take_id ON audio_takes (parent_take_id);
CREATE INDEX idx_audio_takes_active_status_segment_created ON audio_takes (is_active, status, generation_segment_id, created_at DESC, id DESC);
CREATE INDEX ix_audio_takes_generation_run_id ON audio_takes (generation_run_id);
CREATE INDEX ix_audio_takes_artifact_id ON audio_takes (artifact_id);
CREATE INDEX ix_output_assemblies_job_id ON output_assemblies (job_id);
CREATE INDEX idx_output_assemblies_session_created ON output_assemblies (session_id, created_at DESC, id DESC);
CREATE INDEX ix_output_assemblies_generation_run_id ON output_assemblies (generation_run_id);
CREATE INDEX ix_output_assemblies_session_id ON output_assemblies (session_id);
CREATE INDEX ix_media_edit_dispatch_batches_status ON media_edit_dispatch_batches (status);
CREATE INDEX ix_media_edit_dispatch_batches_dispatch_run_id ON media_edit_dispatch_batches (dispatch_run_id);
CREATE INDEX ix_media_edit_dispatch_batches_lease_expires_at ON media_edit_dispatch_batches (lease_expires_at);
CREATE UNIQUE INDEX uq_generation_run_sequence ON generation_runs (session_id, sequence_number);
CREATE INDEX ix_project_sound_plans_session_revision ON project_sound_plans (session_id, revision);
CREATE INDEX ix_project_sound_cues_plan_logical ON project_sound_cues (plan_id, logical_id);
CREATE INDEX ix_browser_auth_sessions_user_id ON browser_auth_sessions (user_id);
CREATE INDEX ix_password_reset_grants_user_id ON password_reset_grants (user_id);
CREATE INDEX ix_job_actors_user_id ON job_actors (user_id);
CREATE INDEX ix_audit_actors_user_id ON audit_actors (user_id);
CREATE INDEX ix_providers_workspace_id ON providers (workspace_id);
CREATE INDEX ix_sessions_purge_after ON sessions (purge_after);
CREATE INDEX ix_sessions_updated_at ON sessions (updated_at);
CREATE INDEX ix_sessions_project_id ON sessions (project_id);
CREATE INDEX ix_sessions_status ON sessions (status);
CREATE INDEX ix_sessions_legacy_name ON sessions (legacy_name);
CREATE INDEX ix_project_folders_parent_id ON project_folders (parent_id);
CREATE INDEX ix_project_folders_workspace_id ON project_folders (workspace_id);
CREATE INDEX ix_project_folder_memberships_project_session_id ON project_folder_memberships (project_session_id);
CREATE INDEX ix_source_assets_content_hash ON source_assets (content_hash);
CREATE INDEX ix_source_assets_workspace_id ON source_assets (workspace_id);
CREATE INDEX ix_source_assets_artifact_id ON source_assets (artifact_id);
CREATE INDEX ix_source_assets_state ON source_assets (state);
CREATE INDEX ix_jobs_lease_owner ON jobs (lease_owner);
CREATE INDEX idx_jobs_status_created ON jobs (status, created_at, id);
CREATE INDEX ix_jobs_workspace_id ON jobs (workspace_id);
CREATE INDEX ix_jobs_available_at ON jobs (available_at);
CREATE INDEX ix_jobs_lease_expires_at ON jobs (lease_expires_at);
CREATE INDEX ix_jobs_status ON jobs (status);
CREATE INDEX ix_jobs_kind ON jobs (kind);
CREATE INDEX ix_jobs_project_id ON jobs (project_id);
CREATE INDEX ix_jobs_session_id ON jobs (session_id);
CREATE INDEX ix_jobs_created_at ON jobs (created_at);
CREATE INDEX ix_artifacts_workspace_id ON artifacts (workspace_id);
CREATE INDEX ix_artifacts_session_id ON artifacts (session_id);
CREATE INDEX ix_artifacts_content_hash ON artifacts (content_hash);
CREATE INDEX ix_artifacts_project_id ON artifacts (project_id);
CREATE INDEX ix_artifacts_kind ON artifacts (kind);
CREATE INDEX ix_upload_sessions_session_id ON upload_sessions (session_id);
CREATE INDEX ix_upload_sessions_expires_at ON upload_sessions (expires_at);
CREATE INDEX ix_upload_sessions_workspace_id ON upload_sessions (workspace_id);
CREATE INDEX ix_upload_sessions_project_id ON upload_sessions (project_id);
CREATE INDEX ix_upload_sessions_state ON upload_sessions (state);
CREATE INDEX ix_research_cache_entries_operation ON research_cache_entries (operation);
CREATE INDEX ix_research_cache_entries_provider ON research_cache_entries (provider);
CREATE INDEX ix_research_cache_entries_workspace_id ON research_cache_entries (workspace_id);
CREATE INDEX ix_research_cache_entries_project_id ON research_cache_entries (project_id);
CREATE INDEX ix_research_cache_entries_expires_at ON research_cache_entries (expires_at);
CREATE INDEX ix_pronunciation_entries_normalized_form ON pronunciation_entries (normalized_form);
CREATE INDEX ix_pronunciation_entries_workspace_id ON pronunciation_entries (workspace_id);
CREATE INDEX ix_pronunciation_entries_scope ON pronunciation_entries (scope);
CREATE INDEX ix_pronunciation_entries_backend ON pronunciation_entries (backend);
CREATE INDEX ix_pronunciation_entries_language ON pronunciation_entries (language);
CREATE INDEX ix_pronunciation_entries_status ON pronunciation_entries (status);
CREATE INDEX ix_pronunciation_entries_project_id ON pronunciation_entries (project_id);
CREATE UNIQUE INDEX uq_pronunciation_entries_workspace_global ON pronunciation_entries (workspace_id, normalized_form, language, backend) WHERE scope = 'global' AND session_id IS NULL;
CREATE INDEX ix_pronunciation_entries_session_id ON pronunciation_entries (session_id);
CREATE INDEX ix_voices_workspace_id ON voices (workspace_id);
CREATE INDEX ix_voice_samples_voice_id ON voice_samples (voice_id);
CREATE INDEX ix_voice_samples_workspace_id ON voice_samples (workspace_id);
CREATE INDEX ix_training_runs_workspace_id ON training_runs (workspace_id);
CREATE INDEX ix_training_runs_voice_id ON training_runs (voice_id);
CREATE INDEX ix_training_runs_status ON training_runs (status);
CREATE INDEX ix_training_runs_workspace_created_at_id ON training_runs (workspace_id, created_at, id);
CREATE INDEX ix_usage_events_artifact_id ON usage_events (artifact_id);
CREATE INDEX ix_usage_events_generation_run_id ON usage_events (generation_run_id);
CREATE INDEX ix_usage_events_job_id ON usage_events (job_id);
CREATE INDEX ix_usage_events_project_id ON usage_events (project_id);
CREATE INDEX ix_usage_events_session_id ON usage_events (session_id);
CREATE INDEX ix_usage_events_workspace_id ON usage_events (workspace_id);
CREATE INDEX ix_usage_events_agent_run_id ON usage_events (agent_run_id);
CREATE INDEX ix_usage_events_created_at ON usage_events (created_at);
CREATE INDEX ix_voice_collections_workspace_id ON voice_collections (workspace_id);
CREATE INDEX ix_voice_collection_members_workspace_id ON voice_collection_members (workspace_id);
CREATE INDEX ix_sound_items_archived_created_at_id ON sound_items (archived, created_at, id);
CREATE INDEX ix_sound_items_workspace_archived_created_at_id ON sound_items (workspace_id, archived, created_at, id);
CREATE INDEX ix_sound_items_workspace_id ON sound_items (workspace_id);
CREATE INDEX ix_sound_variants_workspace_fingerprint_state ON sound_variants (workspace_id, fingerprint, state);
CREATE INDEX ix_sound_variants_workspace_id ON sound_variants (workspace_id);
CREATE INDEX ix_sound_variants_item_created_at_id ON sound_variants (item_id, created_at, id);
CREATE INDEX ix_sound_variants_workspace_created_at_id ON sound_variants (workspace_id, created_at, id);
CREATE INDEX ix_sound_variants_fingerprint_state ON sound_variants (fingerprint, state);
CREATE INDEX idx_artifacts_session_role_created ON artifacts (session_id, role, created_at DESC, id DESC);
CREATE INDEX idx_jobs_session_kind_created ON jobs (session_id, kind, created_at DESC, id DESC);
CREATE INDEX idx_usage_events_session_stage_created ON usage_events (session_id, stage, created_at DESC, id DESC);
CREATE TRIGGER pandrator_project_graph_projects_insert
BEFORE INSERT ON projects
WHEN NEW.source_session_id IS NOT NULL
 AND NOT EXISTS (
    SELECT 1 FROM sessions AS source
    WHERE source.id = NEW.source_session_id
      AND source.project_id = NEW.id
 )
BEGIN
    SELECT RAISE(ABORT, 'project source must belong to project');
END;
CREATE TRIGGER pandrator_project_graph_projects_update
BEFORE UPDATE OF workspace_id, source_session_id ON projects
BEGIN
    SELECT RAISE(ABORT, 'project workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'project source must belong to project')
    WHERE NEW.source_session_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM sessions AS source
          WHERE source.id = NEW.source_session_id
            AND source.project_id = NEW.id
      );

    SELECT RAISE(ABORT, 'project source is immutable after attachment')
    WHERE OLD.source_session_id IS NOT NULL
      AND NEW.source_session_id IS NOT NULL
      AND NEW.source_session_id IS NOT OLD.source_session_id;

    SELECT RAISE(ABORT, 'project source cannot be cleared while its session exists')
    WHERE OLD.source_session_id IS NOT NULL
      AND NEW.source_session_id IS NULL
      AND EXISTS (
          SELECT 1 FROM sessions AS source
          WHERE source.id = OLD.source_session_id
      );
END;
CREATE TRIGGER pandrator_project_graph_sessions_update
BEFORE UPDATE OF project_id ON sessions
WHEN NEW.project_id IS NOT OLD.project_id
BEGIN
    SELECT RAISE(ABORT, 'session project is immutable');
END;
CREATE TRIGGER pandrator_project_graph_translation_projects_insert
BEFORE INSERT ON translation_projects
WHEN NOT EXISTS (
    SELECT 1
    FROM projects AS project
    JOIN sessions AS source ON source.id = project.source_session_id
    WHERE project.id = NEW.project_root_id
      AND project.source_session_id IS NEW.source_session_id
      AND source.project_id IS NEW.project_root_id
)
BEGIN
    SELECT RAISE(ABORT, 'translation project root and source do not match');
END;
CREATE TRIGGER pandrator_project_graph_translation_projects_update
BEFORE UPDATE OF project_root_id, source_session_id ON translation_projects
WHEN NEW.project_root_id IS NOT OLD.project_root_id
  OR NEW.source_session_id IS NOT OLD.source_session_id
BEGIN
    SELECT RAISE(ABORT, 'translation project root and source are immutable');
END;
CREATE TRIGGER pandrator_project_graph_translation_project_branches_insert
BEFORE INSERT ON translation_project_branches
WHEN NOT EXISTS (
    SELECT 1
    FROM translation_projects AS translation
    JOIN projects AS project ON project.id = translation.project_root_id
    JOIN sessions AS branch ON branch.id = NEW.session_id
    WHERE translation.id = NEW.project_id
      AND branch.project_id IS project.id
      AND branch.id IS NOT translation.source_session_id
)
BEGIN
    SELECT RAISE(ABORT, 'translation branch does not belong to its project root');
END;
CREATE TRIGGER pandrator_project_graph_translation_project_branches_update
BEFORE UPDATE OF project_id, session_id ON translation_project_branches
WHEN NEW.project_id IS NOT OLD.project_id
  OR NEW.session_id IS NOT OLD.session_id
BEGIN
    SELECT RAISE(ABORT, 'translation branch project and session are immutable');
END;
CREATE TRIGGER pandrator_project_graph_project_folders_insert
BEFORE INSERT ON project_folders
BEGIN
    SELECT RAISE(ABORT, 'project folder hierarchy contains a cycle')
    WHERE NEW.parent_id IS NOT NULL
      AND EXISTS (
          WITH RECURSIVE ancestors(id) AS (
              SELECT NEW.parent_id
              UNION
              SELECT parent.parent_id
              FROM project_folders AS parent
              JOIN ancestors ON parent.id = ancestors.id
              WHERE parent.parent_id IS NOT NULL
          )
          SELECT 1 FROM ancestors WHERE id IS NEW.id
      );

    SELECT RAISE(ABORT, 'project folder parent must share its workspace')
    WHERE NEW.parent_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM project_folders AS parent
          WHERE parent.id = NEW.parent_id
            AND parent.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_project_graph_project_folders_update
BEFORE UPDATE OF workspace_id, parent_id ON project_folders
BEGIN
    SELECT RAISE(ABORT, 'project folder workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'project folder hierarchy contains a cycle')
    WHERE NEW.parent_id IS NOT NULL
      AND EXISTS (
          WITH RECURSIVE ancestors(id) AS (
              SELECT NEW.parent_id
              UNION
              SELECT parent.parent_id
              FROM project_folders AS parent
              JOIN ancestors ON parent.id = ancestors.id
              WHERE parent.parent_id IS NOT NULL
          )
          SELECT 1 FROM ancestors WHERE id IS NEW.id
      );

    SELECT RAISE(ABORT, 'project folder parent must share its workspace')
    WHERE NEW.parent_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM project_folders AS parent
          WHERE parent.id = NEW.parent_id
            AND parent.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_project_graph_project_folder_memberships_insert
BEFORE INSERT ON project_folder_memberships
WHEN NOT EXISTS (
    SELECT 1
    FROM project_folders AS folder
    JOIN projects AS project ON project.id = NEW.project_id
    JOIN sessions AS source ON source.id = NEW.project_session_id
    WHERE folder.id = NEW.folder_id
      AND folder.workspace_id IS project.workspace_id
      AND project.source_session_id IS NOT NULL
      AND NEW.project_session_id IS project.source_session_id
      AND source.project_id IS project.id
)
BEGIN
    SELECT RAISE(ABORT, 'project folder membership roots do not match');
END;
CREATE TRIGGER pandrator_project_graph_project_folder_memberships_update
BEFORE UPDATE OF folder_id, project_id, project_session_id ON project_folder_memberships
WHEN NOT EXISTS (
    SELECT 1
    FROM project_folders AS folder
    JOIN projects AS project ON project.id = NEW.project_id
    JOIN sessions AS source ON source.id = NEW.project_session_id
    WHERE folder.id = NEW.folder_id
      AND folder.workspace_id IS project.workspace_id
      AND project.source_session_id IS NOT NULL
      AND NEW.project_session_id IS project.source_session_id
      AND source.project_id IS project.id
)
BEGIN
    SELECT RAISE(ABORT, 'project folder membership roots do not match');
END;
CREATE TRIGGER pandrator_media_scope_artifacts_insert
BEFORE INSERT ON artifacts
BEGIN
    SELECT RAISE(ABORT, 'artifact workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'artifact project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'artifact session must belong to its project')
    WHERE NEW.session_id IS NOT NULL
      AND (
          NEW.project_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id = member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE TRIGGER pandrator_media_scope_artifacts_update
BEFORE UPDATE OF workspace_id, project_id, session_id ON artifacts
BEGIN
    SELECT RAISE(ABORT, 'artifact workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'artifact project is immutable')
    WHERE NEW.project_id IS NOT OLD.project_id
      AND NOT (
          OLD.project_id IS NOT NULL
          AND NEW.project_id IS NULL
          AND NOT EXISTS (
              SELECT 1 FROM projects AS project
              WHERE project.id IS OLD.project_id
          )
      );

    SELECT RAISE(ABORT, 'artifact workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'artifact project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'artifact session must belong to its project')
    WHERE NEW.session_id IS NOT NULL
      AND (
          NEW.project_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id = member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE TRIGGER pandrator_media_scope_source_assets_insert
BEFORE INSERT ON source_assets
BEGIN
    SELECT RAISE(ABORT, 'source asset workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'source asset artifact must share its workspace')
    WHERE NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_media_scope_source_assets_update
BEFORE UPDATE OF workspace_id, artifact_id ON source_assets
BEGIN
    SELECT RAISE(ABORT, 'source asset workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'source asset workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'source asset artifact must share its workspace')
    WHERE NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_media_scope_upload_sessions_insert
BEFORE INSERT ON upload_sessions
BEGIN
    SELECT RAISE(ABORT, 'upload workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'upload project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'upload session must belong to its project')
    WHERE NEW.session_id IS NOT NULL
      AND (
          NEW.project_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id = member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE TRIGGER pandrator_media_scope_upload_sessions_update
BEFORE UPDATE OF workspace_id, project_id, session_id ON upload_sessions
BEGIN
    SELECT RAISE(ABORT, 'upload ownership is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id
       OR NEW.project_id IS NOT OLD.project_id
       OR NEW.session_id IS NOT OLD.session_id;

    SELECT RAISE(ABORT, 'upload workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'upload project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'upload session must belong to its project')
    WHERE NEW.session_id IS NOT NULL
      AND (
          NEW.project_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id = member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE TRIGGER pandrator_media_scope_sources_insert
BEFORE INSERT ON sources
WHEN NEW.artifact_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'source artifact must share its session workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN workspaces AS workspace ON workspace.id = project.workspace_id
        JOIN artifacts AS artifact ON artifact.id = NEW.artifact_id
        WHERE member.id IS NEW.session_id
          AND artifact.workspace_id IS workspace.id
    );
END;
CREATE TRIGGER pandrator_media_scope_sources_update
BEFORE UPDATE OF session_id, artifact_id ON sources
WHEN NEW.artifact_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'source artifact must share its session workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN workspaces AS workspace ON workspace.id = project.workspace_id
        JOIN artifacts AS artifact ON artifact.id = NEW.artifact_id
        WHERE member.id IS NEW.session_id
          AND artifact.workspace_id IS workspace.id
    );
END;
CREATE TRIGGER pandrator_media_scope_session_sources_insert
BEFORE INSERT ON session_sources
BEGIN
    SELECT RAISE(ABORT, 'session source session must resolve to a workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN workspaces AS workspace ON workspace.id = project.workspace_id
        WHERE member.id IS NEW.session_id
    );

    SELECT RAISE(ABORT, 'session source asset must share its session workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN source_assets AS asset ON asset.id = NEW.source_asset_id
        WHERE member.id IS NEW.session_id
          AND asset.workspace_id IS project.workspace_id
    );
END;
CREATE TRIGGER pandrator_media_scope_session_sources_update
BEFORE UPDATE OF session_id, source_asset_id ON session_sources
BEGIN
    SELECT RAISE(ABORT, 'session source session must resolve to a workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN workspaces AS workspace ON workspace.id = project.workspace_id
        WHERE member.id IS NEW.session_id
    );

    SELECT RAISE(ABORT, 'session source asset must share its session workspace')
    WHERE NOT EXISTS (
        SELECT 1
        FROM sessions AS member
        JOIN projects AS project ON project.id = member.project_id
        JOIN source_assets AS asset ON asset.id = NEW.source_asset_id
        WHERE member.id IS NEW.session_id
          AND asset.workspace_id IS project.workspace_id
    );
END;
CREATE TRIGGER pandrator_library_scope_voices_update
BEFORE UPDATE OF workspace_id ON voices
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'voice workspace is immutable');
END;
CREATE TRIGGER pandrator_library_scope_voice_collections_update
BEFORE UPDATE OF workspace_id ON voice_collections
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'voice collection workspace is immutable');
END;
CREATE TRIGGER pandrator_library_scope_jobs_update
BEFORE UPDATE OF workspace_id ON jobs
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'job workspace is immutable');
END;
CREATE TRIGGER pandrator_library_scope_voice_samples_insert
BEFORE INSERT ON voice_samples
BEGIN
    SELECT RAISE(ABORT, 'voice sample voice must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM voices AS voice
        WHERE voice.id IS NEW.voice_id
          AND voice.workspace_id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'voice sample artifact must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM artifacts AS artifact
        WHERE artifact.id IS NEW.artifact_id
          AND artifact.workspace_id IS NEW.workspace_id
    );
END;
CREATE TRIGGER pandrator_library_scope_voice_samples_update
BEFORE UPDATE OF workspace_id, voice_id, artifact_id ON voice_samples
BEGIN
    SELECT RAISE(ABORT, 'voice sample workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'voice sample voice is immutable')
    WHERE NEW.voice_id IS NOT OLD.voice_id;

    SELECT RAISE(ABORT, 'voice sample voice must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM voices AS voice
        WHERE voice.id IS NEW.voice_id
          AND voice.workspace_id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'voice sample artifact must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM artifacts AS artifact
        WHERE artifact.id IS NEW.artifact_id
          AND artifact.workspace_id IS NEW.workspace_id
    );
END;
CREATE TRIGGER pandrator_library_scope_training_runs_insert
BEFORE INSERT ON training_runs
BEGIN
    SELECT RAISE(ABORT, 'training voice must share its workspace')
    WHERE NEW.voice_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM voices AS voice
          WHERE voice.id IS NEW.voice_id
            AND voice.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training job must share its workspace')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training source artifact must share its workspace')
    WHERE NEW.source_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.source_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training text artifact must share its workspace')
    WHERE NEW.source_text_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.source_text_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training output artifact must share its workspace')
    WHERE NEW.output_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.output_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_training_runs_update
BEFORE UPDATE OF workspace_id, voice_id, job_id, source_artifact_id,
    source_text_artifact_id, output_artifact_id ON training_runs
BEGIN
    SELECT RAISE(ABORT, 'training workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'training voice must share its workspace')
    WHERE NEW.voice_id IS NOT OLD.voice_id
      AND NEW.voice_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM voices AS voice
          WHERE voice.id IS NEW.voice_id
            AND voice.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training job must share its workspace')
    WHERE NEW.job_id IS NOT OLD.job_id
      AND NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training source artifact must share its workspace')
    WHERE NEW.source_artifact_id IS NOT OLD.source_artifact_id
      AND NEW.source_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.source_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training text artifact must share its workspace')
    WHERE NEW.source_text_artifact_id IS NOT OLD.source_text_artifact_id
      AND NEW.source_text_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.source_text_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'training output artifact must share its workspace')
    WHERE NEW.output_artifact_id IS NOT OLD.output_artifact_id
      AND NEW.output_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.output_artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_voice_collection_members_insert
BEFORE INSERT ON voice_collection_members
BEGIN
    SELECT RAISE(ABORT, 'voice collection must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM voice_collections AS collection
        WHERE collection.id IS NEW.collection_id
          AND collection.workspace_id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'managed voice must share its workspace')
    WHERE NEW.managed_voice_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM voices AS voice
          WHERE voice.id IS NEW.managed_voice_id
            AND voice.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_voice_collection_members_update
BEFORE UPDATE ON voice_collection_members
BEGIN
    SELECT RAISE(ABORT, 'voice collection member workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'voice collection must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM voice_collections AS collection
        WHERE collection.id IS NEW.collection_id
          AND collection.workspace_id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'managed voice must share its workspace')
    WHERE NEW.managed_voice_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM voices AS voice
          WHERE voice.id IS NEW.managed_voice_id
            AND voice.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_sound_items_insert
BEFORE INSERT ON sound_items
WHEN NEW.preferred_variant_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'preferred sound variant must belong to its item')
    WHERE NOT EXISTS (
        SELECT 1 FROM sound_variants AS variant
        WHERE variant.id IS NEW.preferred_variant_id
          AND variant.workspace_id IS NEW.workspace_id
          AND variant.item_id IS NEW.id
    );
END;
CREATE TRIGGER pandrator_library_scope_sound_items_update
BEFORE UPDATE OF workspace_id, preferred_variant_id ON sound_items
BEGIN
    SELECT RAISE(ABORT, 'sound item workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'preferred sound variant must belong to its item')
    WHERE NEW.preferred_variant_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM sound_variants AS variant
          WHERE variant.id IS NEW.preferred_variant_id
            AND variant.workspace_id IS NEW.workspace_id
            AND variant.item_id IS NEW.id
      );
END;
CREATE TRIGGER pandrator_library_scope_sound_variants_insert
BEFORE INSERT ON sound_variants
BEGIN
    SELECT RAISE(ABORT, 'sound variant item must share its workspace')
    WHERE NEW.item_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM sound_items AS item
          WHERE item.id IS NEW.item_id
            AND item.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'sound variant job must share its workspace')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'sound variant artifact must share its workspace')
    WHERE NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_sound_variants_update
BEFORE UPDATE OF workspace_id, item_id, job_id, artifact_id ON sound_variants
BEGIN
    SELECT RAISE(ABORT, 'sound variant workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'sound variant item attachment is immutable')
    WHERE OLD.item_id IS NOT NULL
      AND NEW.item_id IS NOT OLD.item_id;

    SELECT RAISE(ABORT, 'sound variant item must share its workspace')
    WHERE NEW.item_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM sound_items AS item
          WHERE item.id IS NEW.item_id
            AND item.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'sound variant job must share its workspace')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'sound variant artifact must share its workspace')
    WHERE NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
      );
END;
CREATE TRIGGER pandrator_library_scope_research_cache_entries_insert
BEFORE INSERT ON research_cache_entries
WHEN NEW.project_id IS NOT NULL
BEGIN
    SELECT RAISE(ABORT, 'research cache project must share its workspace')
    WHERE NOT EXISTS (
        SELECT 1 FROM projects AS project
        WHERE project.id IS NEW.project_id
          AND project.workspace_id IS NEW.workspace_id
    );
END;
CREATE TRIGGER pandrator_library_scope_research_cache_entries_update
BEFORE UPDATE OF workspace_id, project_id ON research_cache_entries
BEGIN
    SELECT RAISE(ABORT, 'research cache workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'research cache project is immutable')
    WHERE NEW.project_id IS NOT OLD.project_id;
END;
CREATE TRIGGER pandrator_execution_scope_jobs_insert
BEFORE INSERT ON jobs
BEGIN
    SELECT RAISE(ABORT, 'job workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'job project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'job session must match its project')
    WHERE NEW.session_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM sessions AS member
          JOIN projects AS project ON project.id = member.project_id
          WHERE member.id IS NEW.session_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'job workflow must match its project and session')
    WHERE NEW.workflow_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM workflow_runs AS workflow
          JOIN sessions AS member ON member.id = workflow.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE workflow.id IS NEW.workflow_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
            AND (NEW.session_id IS NULL OR workflow.session_id IS NEW.session_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_jobs_update
BEFORE UPDATE OF workspace_id, project_id, session_id, workflow_run_id ON jobs
WHEN NEW.workspace_id IS NOT OLD.workspace_id
  OR NEW.project_id IS NOT OLD.project_id
  OR NEW.session_id IS NOT OLD.session_id
  OR NEW.workflow_run_id IS NOT OLD.workflow_run_id
BEGIN
    SELECT RAISE(ABORT, 'job execution roots are immutable');
END;
CREATE TRIGGER pandrator_execution_scope_workflow_runs_update
BEFORE UPDATE OF session_id ON workflow_runs
WHEN NEW.session_id IS NOT OLD.session_id
BEGIN
    SELECT RAISE(ABORT, 'workflow session is immutable');
END;
CREATE TRIGGER pandrator_execution_scope_generation_runs_insert
BEFORE INSERT ON generation_runs
BEGIN
    SELECT RAISE(ABORT, 'generation job must share its session scope')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM jobs AS job
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS project.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS member.project_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_generation_runs_update
BEFORE UPDATE OF session_id, job_id ON generation_runs
BEGIN
    SELECT RAISE(ABORT, 'generation session is immutable')
    WHERE NEW.session_id IS NOT OLD.session_id;

    SELECT RAISE(ABORT, 'generation job must share its session scope')
    WHERE NEW.job_id IS NOT OLD.job_id
      AND NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM jobs AS job
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS project.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS member.project_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_agent_runs_insert
BEFORE INSERT ON agent_runs
BEGIN
    SELECT RAISE(ABORT, 'agent job must share its session scope')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM jobs AS job
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS project.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS member.project_id)
      );

    SELECT RAISE(ABORT, 'agent source artifact must share its session workspace')
    WHERE NEW.source_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM artifacts AS artifact
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE artifact.id IS NEW.source_artifact_id
            AND artifact.workspace_id IS project.workspace_id
      );

    SELECT RAISE(ABORT, 'agent result artifact must share its session scope')
    WHERE NEW.result_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM artifacts AS artifact
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE artifact.id IS NEW.result_artifact_id
            AND artifact.workspace_id IS project.workspace_id
            AND (artifact.project_id IS NULL OR artifact.project_id IS member.project_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_agent_runs_update
BEFORE UPDATE OF session_id, job_id, source_artifact_id, result_artifact_id ON agent_runs
BEGIN
    SELECT RAISE(ABORT, 'agent session is immutable')
    WHERE NEW.session_id IS NOT OLD.session_id;

    SELECT RAISE(ABORT, 'agent job must share its session scope')
    WHERE NEW.job_id IS NOT OLD.job_id
      AND NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM jobs AS job
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS project.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS member.project_id)
      );

    SELECT RAISE(ABORT, 'agent source artifact must share its session workspace')
    WHERE NEW.source_artifact_id IS NOT OLD.source_artifact_id
      AND NEW.source_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM artifacts AS artifact
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE artifact.id IS NEW.source_artifact_id
            AND artifact.workspace_id IS project.workspace_id
      );

    SELECT RAISE(ABORT, 'agent result artifact must share its session scope')
    WHERE NEW.result_artifact_id IS NOT OLD.result_artifact_id
      AND NEW.result_artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM artifacts AS artifact
          JOIN sessions AS member ON member.id IS NEW.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE artifact.id IS NEW.result_artifact_id
            AND artifact.workspace_id IS project.workspace_id
            AND (artifact.project_id IS NULL OR artifact.project_id IS member.project_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_usage_events_insert
BEFORE INSERT ON usage_events
BEGIN
    SELECT RAISE(ABORT, 'usage workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'usage project must share its workspace')
    WHERE NEW.project_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM projects AS project
          WHERE project.id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage session must match its stored scope')
    WHERE NEW.session_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM sessions AS member
          JOIN projects AS project ON project.id = member.project_id
          WHERE member.id IS NEW.session_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage workflow must match its stored scope')
    WHERE NEW.workflow_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM workflow_runs AS workflow
          JOIN sessions AS member ON member.id = workflow.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE workflow.id IS NEW.workflow_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage generation must match its stored scope')
    WHERE NEW.generation_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM generation_runs AS generation
          JOIN sessions AS member ON member.id = generation.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE generation.id IS NEW.generation_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage agent must match its stored scope')
    WHERE NEW.agent_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM agent_runs AS agent
          JOIN sessions AS member ON member.id = agent.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE agent.id IS NEW.agent_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage job must match its stored scope')
    WHERE NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS NEW.project_id)
      );

    SELECT RAISE(ABORT, 'usage artifact must match its stored scope')
    WHERE NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
            AND (artifact.project_id IS NULL OR artifact.project_id IS NEW.project_id)
      );
END;
CREATE TRIGGER pandrator_execution_scope_usage_events_update
BEFORE UPDATE OF workspace_id, project_id, session_id, workflow_run_id, job_id,
    artifact_id, generation_run_id, agent_run_id ON usage_events
BEGIN
    SELECT RAISE(ABORT, 'usage scope is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id
       OR NEW.project_id IS NOT OLD.project_id;

    SELECT RAISE(ABORT, 'usage session must match its stored scope')
    WHERE NEW.session_id IS NOT OLD.session_id
      AND NEW.session_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM sessions AS member
          JOIN projects AS project ON project.id = member.project_id
          WHERE member.id IS NEW.session_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage workflow must match its stored scope')
    WHERE NEW.workflow_run_id IS NOT OLD.workflow_run_id
      AND NEW.workflow_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM workflow_runs AS workflow
          JOIN sessions AS member ON member.id = workflow.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE workflow.id IS NEW.workflow_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage generation must match its stored scope')
    WHERE NEW.generation_run_id IS NOT OLD.generation_run_id
      AND NEW.generation_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM generation_runs AS generation
          JOIN sessions AS member ON member.id = generation.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE generation.id IS NEW.generation_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage agent must match its stored scope')
    WHERE NEW.agent_run_id IS NOT OLD.agent_run_id
      AND NEW.agent_run_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM agent_runs AS agent
          JOIN sessions AS member ON member.id = agent.session_id
          JOIN projects AS project ON project.id = member.project_id
          WHERE agent.id IS NEW.agent_run_id
            AND member.project_id IS NEW.project_id
            AND project.workspace_id IS NEW.workspace_id
      );

    SELECT RAISE(ABORT, 'usage job must match its stored scope')
    WHERE NEW.job_id IS NOT OLD.job_id
      AND NEW.job_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM jobs AS job
          WHERE job.id IS NEW.job_id
            AND job.workspace_id IS NEW.workspace_id
            AND (job.project_id IS NULL OR job.project_id IS NEW.project_id)
      );

    SELECT RAISE(ABORT, 'usage artifact must match its stored scope')
    WHERE NEW.artifact_id IS NOT OLD.artifact_id
      AND NEW.artifact_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM artifacts AS artifact
          WHERE artifact.id IS NEW.artifact_id
            AND artifact.workspace_id IS NEW.workspace_id
            AND (artifact.project_id IS NULL OR artifact.project_id IS NEW.project_id)
      );
END;
CREATE TRIGGER pandrator_configuration_scope_providers_update
BEFORE UPDATE OF workspace_id ON providers
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'provider workspace is immutable');
END;
CREATE TRIGGER pandrator_configuration_scope_stored_credentials_update
BEFORE UPDATE OF workspace_id ON stored_credentials
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'stored credential workspace is immutable');
END;
CREATE TRIGGER pandrator_configuration_scope_workspace_settings_update
BEFORE UPDATE OF workspace_id ON workspace_settings
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'workspace setting workspace is immutable');
END;
CREATE TRIGGER pandrator_configuration_scope_workspace_settings_history_update
BEFORE UPDATE OF workspace_id ON workspace_settings_history
WHEN NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'workspace setting history workspace is immutable');
END;
CREATE TRIGGER pandrator_configuration_scope_pronunciation_entries_insert
BEFORE INSERT ON pronunciation_entries
BEGIN
    SELECT RAISE(ABORT, 'pronunciation workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'pronunciation scope is invalid')
    WHERE NEW.scope IS NOT 'global' AND NEW.scope IS NOT 'session';

    SELECT RAISE(ABORT, 'global pronunciation cannot have project or session roots')
    WHERE NEW.scope IS 'global'
      AND (NEW.project_id IS NOT NULL OR NEW.session_id IS NOT NULL);

    SELECT RAISE(ABORT, 'session pronunciation roots are inconsistent')
    WHERE NEW.scope IS 'session'
      AND (
          NEW.project_id IS NULL
          OR NEW.session_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id IS member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE TRIGGER pandrator_configuration_scope_pronunciation_entries_update
BEFORE UPDATE OF workspace_id, project_id, session_id, scope ON pronunciation_entries
BEGIN
    SELECT RAISE(ABORT, 'pronunciation workspace is immutable')
    WHERE NEW.workspace_id IS NOT OLD.workspace_id;

    SELECT RAISE(ABORT, 'pronunciation workspace does not exist')
    WHERE NOT EXISTS (
        SELECT 1 FROM workspaces AS workspace
        WHERE workspace.id IS NEW.workspace_id
    );

    SELECT RAISE(ABORT, 'pronunciation scope is invalid')
    WHERE NEW.scope IS NOT 'global' AND NEW.scope IS NOT 'session';

    SELECT RAISE(ABORT, 'global pronunciation cannot have project or session roots')
    WHERE NEW.scope IS 'global'
      AND (NEW.project_id IS NOT NULL OR NEW.session_id IS NOT NULL);

    SELECT RAISE(ABORT, 'session pronunciation roots are inconsistent')
    WHERE NEW.scope IS 'session'
      AND (
          NEW.project_id IS NULL
          OR NEW.session_id IS NULL
          OR NOT EXISTS (
              SELECT 1
              FROM sessions AS member
              JOIN projects AS project ON project.id IS member.project_id
              WHERE member.id IS NEW.session_id
                AND member.project_id IS NEW.project_id
                AND project.workspace_id IS NEW.workspace_id
          )
      );
END;
CREATE INDEX ix_api_token_workspace_grants_workspace_id ON api_token_workspace_grants (workspace_id);
CREATE INDEX ix_api_token_project_grants_project_id ON api_token_project_grants (project_id);
CREATE INDEX ix_automation_client_workspace_grants_workspace_id ON automation_client_workspace_grants (workspace_id);
CREATE INDEX ix_automation_client_project_grants_project_id ON automation_client_project_grants (project_id);
CREATE INDEX ix_browser_auth_workspace_grants_workspace_id ON browser_auth_workspace_grants (workspace_id);
CREATE INDEX ix_browser_auth_project_grants_project_id ON browser_auth_project_grants (project_id);
CREATE INDEX ix_automation_code_workspace_grants_workspace_id ON automation_code_workspace_grants (workspace_id);
CREATE INDEX ix_automation_code_project_grants_project_id ON automation_code_project_grants (project_id);
CREATE INDEX ix_quick_transcription_owners_user_id ON quick_transcription_owners (user_id);
CREATE INDEX ix_quick_transcription_owners_workspace_id ON quick_transcription_owners (workspace_id);
CREATE TRIGGER quick_transcription_owners_scope_insert
BEFORE INSERT ON quick_transcription_owners
FOR EACH ROW
WHEN EXISTS (SELECT 1 FROM users WHERE id = NEW.user_id)
  AND EXISTS (SELECT 1 FROM workspaces WHERE id = NEW.workspace_id)
  AND EXISTS (SELECT 1 FROM quick_transcriptions WHERE id = NEW.transcription_id)
  AND (
      NOT EXISTS (
          SELECT 1
          FROM workspaces AS workspace
          WHERE workspace.id = NEW.workspace_id
            AND workspace.kind = 'personal'
            AND workspace.personal_owner_user_id = NEW.user_id
      )
      OR EXISTS (
          SELECT 1
          FROM quick_transcriptions AS transcription
          JOIN jobs AS job ON job.id = transcription.job_id
          WHERE transcription.id = NEW.transcription_id
            AND transcription.job_id IS NOT NULL
            AND (
                job.kind IS NOT 'transcription.quick'
                OR job.workspace_id IS NOT NEW.workspace_id
                OR job.project_id IS NOT NULL
                OR job.session_id IS NOT NULL
                OR job.workflow_run_id IS NOT NULL
            )
      )
)
BEGIN
    SELECT RAISE(ABORT, 'invalid private transcription owner scope');
END;
CREATE TRIGGER quick_transcription_owners_scope_update
BEFORE UPDATE ON quick_transcription_owners
FOR EACH ROW
WHEN NEW.transcription_id IS NOT OLD.transcription_id
  OR NEW.user_id IS NOT OLD.user_id
  OR NEW.workspace_id IS NOT OLD.workspace_id
BEGIN
    SELECT RAISE(ABORT, 'immutable private transcription owner identity');
END;
CREATE TRIGGER workspaces_private_transcription_scope_update
BEFORE UPDATE OF kind, personal_owner_user_id ON workspaces
FOR EACH ROW
WHEN EXISTS (
    SELECT 1
    FROM quick_transcription_owners AS owner
    WHERE owner.workspace_id = OLD.id
      AND (
          NEW.kind IS NOT 'personal'
          OR NEW.personal_owner_user_id IS NOT owner.user_id
      )
)
BEGIN
    SELECT RAISE(ABORT, 'invalid private transcription workspace scope');
END;
CREATE TRIGGER quick_transcriptions_private_job_update
BEFORE UPDATE OF job_id ON quick_transcriptions
FOR EACH ROW
WHEN NEW.job_id IS NOT NULL
  AND EXISTS (
      SELECT 1
      FROM quick_transcription_owners AS owner
      WHERE owner.transcription_id = OLD.id
        AND NOT EXISTS (
            SELECT 1
            FROM jobs AS job
            WHERE job.id = NEW.job_id
              AND job.kind = 'transcription.quick'
              AND job.workspace_id = owner.workspace_id
              AND job.project_id IS NULL
              AND job.session_id IS NULL
              AND job.workflow_run_id IS NULL
        )
  )
BEGIN
    SELECT RAISE(ABORT, 'invalid private transcription job scope');
END;
CREATE TRIGGER jobs_private_transcription_scope_update
BEFORE UPDATE OF workspace_id, project_id, session_id, workflow_run_id, kind ON jobs
FOR EACH ROW
WHEN EXISTS (
    SELECT 1
    FROM quick_transcription_owners AS owner
    JOIN quick_transcriptions AS transcription
      ON transcription.id = owner.transcription_id
    WHERE transcription.job_id = OLD.id
      AND (
          NEW.kind IS NOT 'transcription.quick'
          OR NEW.workspace_id IS NOT owner.workspace_id
          OR NEW.project_id IS NOT NULL
          OR NEW.session_id IS NOT NULL
          OR NEW.workflow_run_id IS NOT NULL
      )
)
BEGIN
    SELECT RAISE(ABORT, 'invalid private transcription job scope');
END;
COMMIT;
